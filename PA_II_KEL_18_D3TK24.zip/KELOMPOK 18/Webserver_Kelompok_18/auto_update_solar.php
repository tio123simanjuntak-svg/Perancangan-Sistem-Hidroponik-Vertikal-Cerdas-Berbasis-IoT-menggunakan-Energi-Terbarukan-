<?php
// ==============================================
// AUTO UPDATE SOLAR DATA + MODE CONTROL
// ==============================================

require_once 'config/database.php';

echo "🚀 Solar Dummy Update - " . date('Y-m-d H:i:s') . "\n";

$mode = isset($argv[1]) ? strtolower($argv[1]) : 'auto';

if ($mode === 'mengisi' || $mode === 'isi') {
    $force_mengisi = true;
} elseif ($mode === 'tidak' || $mode === 'mati' || $mode === 'off') {
    $force_mengisi = false;
} else {
    $current_hour = (int)date('H');
    $force_mengisi = ($current_hour >= 6 && $current_hour < 18);
}

if ($force_mengisi) {
    $arus_surya     = round(rand(28, 52) / 10, 2); // fix: rand hanya integer
    $tegangan_surya = round(13.8 + ($arus_surya * 0.5), 2);
    $baterai        = rand(80, 98);
    $battery_voltage= round(12.0 + ($baterai / 100), 2);
    $pump_status    = 1;
    $status_text    = "MENGISI";
} else {
    $arus_surya     = 0.00;
    $tegangan_surya = 0.00;
    $baterai        = rand(50, 68);
    $battery_voltage= round(11.5 + ($baterai / 100), 2);
    $pump_status    = 0;
    $status_text    = "TIDAK MENGISI";
}

echo "Mode          : {$status_text}\n";
echo "Solar Current : {$arus_surya} A\n";
echo "Solar Voltage : {$tegangan_surya} V\n";
echo "Battery Level : {$baterai}%\n";
echo "Battery Volt  : {$battery_voltage} V\n";

// Update Database - kolom sesuai tabel sensor_data
$sql = "UPDATE sensor_data 
        SET 
            arus_surya      = ?,
            tegangan_surya  = ?,
            baterai         = ?,
            battery_voltage = ?,
            pump_status     = ?
        ORDER BY id DESC 
        LIMIT 1";

$stmt = $conn->prepare($sql);

if ($stmt) {
    $stmt->bind_param("ddidi", $arus_surya, $tegangan_surya, $baterai, $battery_voltage, $pump_status);
    
    if ($stmt->execute()) {
        echo "✅ Berhasil update ke mode {$status_text}!\n";
    } else {
        echo "❌ Gagal update: " . $stmt->error . "\n";
    }
    $stmt->close();
} else {
    echo "❌ Prepare gagal: " . $conn->error . "\n";
}

$conn->close();
?>