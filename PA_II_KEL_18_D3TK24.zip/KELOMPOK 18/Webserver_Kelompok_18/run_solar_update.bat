.\run_solar_update.bat@echo off
echo ==============================================
echo        AUTO UPDATE SOLAR DATA
echo ==============================================
cd /d "C:\xampp\htdocs\webserver hidroponik vertikal"
php auto_update_solar.php
echo.
echo Selesai. Tekan tombol apa saja untuk keluar...
pause
