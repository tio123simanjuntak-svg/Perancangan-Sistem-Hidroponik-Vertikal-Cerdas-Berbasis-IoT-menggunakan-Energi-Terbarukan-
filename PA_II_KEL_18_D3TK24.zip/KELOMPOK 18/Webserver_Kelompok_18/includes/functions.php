<?php
// ==============================================
// FUNCTIONS FOR HIDROPONIK VERTIKAL - FINAL FIX
// ==============================================

function getLatestSensorData($conn) {
    $query = "SELECT 
                suhu, 
                kelembapan, 
                tds, 
                water_level,
                battery_voltage, 
                baterai, 
                arus_surya, 
                tegangan_surya, 
                pump_status, 
                created_at 
              FROM sensor_data 
              ORDER BY id DESC 
              LIMIT 1";
    
    $result = mysqli_query($conn, $query);          
    if (!$result) {
        error_log("Query Error Latest: " . mysqli_error($conn));
        return false;
    }
    return mysqli_fetch_assoc($result);
}

function getSolarStatus() {
    global $conn;
    $latest = getLatestSensorData($conn);
    if (!$latest) {
        return ['solar_status' => 'IDLE', 'arus_surya' => 0, 'tegangan_surya' => 0, 'baterai' => 0, 'battery_voltage' => 0];
    }
    
    return [
        'solar_status' => ($latest['arus_surya'] > 1.0) ? 'MENGISI' : 'IDLE',
        'arus_surya' => $latest['arus_surya'],
        'tegangan_surya' => $latest['tegangan_surya'],
        'baterai' => $latest['baterai'],
        'battery_voltage' => $latest['battery_voltage']
    ];
}

function getNutrientStatus() {
    global $conn;
    $latest = getLatestSensorData($conn);
    if (!$latest) {
        return ['tds_ppm' => 750, 'water_level' => 80, 'absorption_rate' => 75];
    }
    
    return [
        'tds_ppm' => $latest['tds'],
        'water_level' => $latest['water_level'],
        'absorption_rate' => calculateAbsorption($latest)
    ];
}

function calculateAbsorption($sensor) {
    if (!$sensor) return 75;
    
    $temp = $sensor['suhu'];
    $tds = $sensor['tds'];
    $humidity = $sensor['kelembapan'];   // ← Diperbaiki
    
    $temp_factor = max(0.3, min(1, 1 - abs(($temp - 25.5) / 8)));
    $tds_factor = max(0.3, min(1, 1 - abs(($tds - 775) / 150)));
    $humid_factor = max(0.3, min(1, 1 - abs(($humidity - 67.5) / 20)));
    
    return max(20, min(95, round(($temp_factor + $tds_factor + $humid_factor) / 3 * 100)));
}

function getHistoryData($conn, $limit = 10) {
    $query = "SELECT 
                DATE_FORMAT(created_at, '%H:%i:%s') as waktu,
                suhu,
                kelembapan,
                tds,
                baterai,
                CASE 
                    WHEN pump_status = 1 THEN 'AKTIF' 
                    ELSE 'NONAKTIF' 
                END as pompa,
                created_at as raw_date
              FROM sensor_data 
              ORDER BY id DESC 
              LIMIT " . intval($limit);
    
    $result = mysqli_query($conn, $query);
    if (!$result) {
        error_log("Query Error History: " . mysqli_error($conn));
        return [];
    }
    
    $data = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
    }
    return $data;
}
?>