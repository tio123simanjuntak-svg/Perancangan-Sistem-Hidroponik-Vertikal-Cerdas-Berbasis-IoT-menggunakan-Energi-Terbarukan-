<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

date_default_timezone_set('Asia/Sitoluama');

echo json_encode([
    'time' => date('H:i:s'),
    'date' => date('Y-m-d'),
    'timestamp' => time()
]);
?>