<?php
// ==============================================
// API GENERATE BATCH DATA
// ==============================================

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

require_once '../config/database.php';

$total = 10;
$success = 0;

for ($i = 0; $i < $total; $i++) {
    // Generate data random yang masuk akal
    $suhu = round(20 + (rand(0, 120) / 10), 1); // 20-32°C
    $kelembapan = round(55 + (rand(0, 350) / 10), 1); // 55-90%
    $tds = rand(650, 850);
    $water_level = rand(65, 90);
    $battery_voltage = round(11.0 + (rand(0, 350) / 100), 2); // 11-14.5V
    $baterai = rand(40, 95);
    $arus_surya = round(0 + (rand(0, 550) / 100), 2); // 0-5.5A
    $tegangan_surya = round(11.0 + (rand(0, 500) / 100), 2); // 11-16V
    $pump_status = rand(0, 1);
    
    // Tambahkan variasi berdasarkan jam (simulasi)
    $hour = rand(0, 23);
    if ($hour >= 6 && $hour <= 8) {
        $pump_status = 1; // Pompa aktif pagi
    } elseif ($hour >= 16 && $hour <= 17) {
        $pump_status = 1; // Pompa aktif sore
    } else {
        $pump_status = rand(0, 1) > 0.8 ? 1 : 0;
    }
    
    $query = "INSERT INTO sensor_data (
        suhu, kelembapan, tds, water_level,
        battery_voltage, baterai, arus_surya, tegangan_surya,
        pump_status, created_at
    ) VALUES (
        '$suhu', '$kelembapan', '$tds', '$water_level',
        '$battery_voltage', '$baterai', '$arus_surya', '$tegangan_surya',
        '$pump_status', DATE_SUB(NOW(), INTERVAL " . ($total - $i) . " MINUTE)
    )";
    
    if (mysqli_query($conn, $query)) {
        $success++;
    }
}

echo json_encode([
    'success' => true,
    'message' => "Berhasil generate $success data",
    'total' => $success
]);
?>