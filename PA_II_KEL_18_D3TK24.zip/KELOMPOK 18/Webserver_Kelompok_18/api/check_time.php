<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

date_default_timezone_set('Asia/Sitoluama');

echo json_encode([
    'status' => 'success',
    'data' => [
        'datetime' => date('Y-m-d H:i:s'),
        'date' => date('d F Y'),
        'time' => date('H:i:s'),
        'hour' => (int)date('H'),
        'minute' => (int)date('i'),
        'second' => (int)date('s'),
        'day' => date('l'),
        'timezone' => date_default_timezone_get()
    ]
]);
?>