<?php
// ==============================================
// API PUMP CONTROL
// ==============================================

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

require_once '../config/database.php';

$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
    exit;
}

$action = $input['action'] ?? '';
$duration = isset($input['duration']) ? intval($input['duration']) : 0;

if ($action === 'on') {
    $status = 1;
    $message = $duration ? "Pompa dinyalakan selama {$duration} detik" : 'Pompa dinyalakan';
} elseif ($action === 'off') {
    $status = 0;
    $message = 'Pompa dimatikan';
} else {
    echo json_encode(['success' => false, 'message' => 'Aksi tidak valid']);
    exit;
}

// Insert log aktivitas pump
$logQuery = "INSERT INTO sensor_data (suhu, kelembapan, tds, water_level, battery_voltage, baterai, arus_surya, tegangan_surya, pump_status) 
             SELECT suhu, kelembapan, tds, water_level, battery_voltage, baterai, arus_surya, tegangan_surya, $status 
             FROM sensor_data ORDER BY created_at DESC LIMIT 1";
mysqli_query($conn, $logQuery);

echo json_encode([
    'success' => true,
    'message' => $message,
    'status' => $status,
    'duration' => $duration
]);
?>