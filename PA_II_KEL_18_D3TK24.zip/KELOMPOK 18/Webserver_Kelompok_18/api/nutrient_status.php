<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

require_once 'db.php';

$sql = "SELECT * FROM nutrient_absorption ORDER BY id DESC LIMIT 1";
$result = $conn->query($sql);
$data = $result->fetch_assoc();

if ($data) {
    echo json_encode([
        'status' => 'success',
        'data' => [
            'tds_ppm' => (int)$data['tds_ppm'],
            'ph_level' => (float)$data['ph_level'],
            'nutrient_level' => (int)$data['nutrient_level'],
            'absorption_rate' => (float)$data['absorption_rate'],
            'recommended_tds' => 750,
            'status' => ($data['tds_ppm'] < 500 || $data['tds_ppm'] > 1000) ? 'warning' : 'normal'
        ]
    ]);
} else {
    echo json_encode([
        'status' => 'sementara',
        'data' => [
            'tds_ppm' => 750,
            'ph_level' => 6.8,
            'nutrient_level' => 85,
            'absorption_rate' => 12.5,
            'recommended_tds' => 750,
            'status' => 'normal'
        ]
    ]);
}

$conn->close();
?>