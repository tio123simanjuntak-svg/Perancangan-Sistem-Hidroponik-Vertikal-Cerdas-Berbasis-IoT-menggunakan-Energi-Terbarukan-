<?php
// ==============================================
// API GET LATEST SENSOR DATA
// ==============================================

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

require_once '../config/database.php';

$query = "SELECT 
            suhu, 
            kelembapan, 
            tds, 
            water_level,
            battery_voltage, 
            baterai, 
            arus_surya, 
            tegangan_surya, 
            pump_status, 
            created_at 
          FROM sensor_data 
          ORDER BY created_at DESC 
          LIMIT 1";

$result = mysqli_query($conn, $query);

if ($result && mysqli_num_rows($result) > 0) {
    $data = mysqli_fetch_assoc($result);
    echo json_encode($data);
} else {
    echo json_encode([
        'suhu' => 25.0,
        'kelembapan' => 65.0,
        'tds' => 750,
        'water_level' => 80,
        'battery_voltage' => 12.50,
        'baterai' => 75,
        'arus_surya' => 1.50,
        'tegangan_surya' => 13.20,
        'pump_status' => 0
    ]);
}
?>