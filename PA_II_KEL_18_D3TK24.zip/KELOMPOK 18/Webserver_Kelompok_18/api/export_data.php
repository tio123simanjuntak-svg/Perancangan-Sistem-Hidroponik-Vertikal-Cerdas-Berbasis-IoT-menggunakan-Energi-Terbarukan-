<?php
// ==============================================
// API EXPORT DATA
// ==============================================

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

require_once '../config/database.php';

$query = "SELECT 
            DATE_FORMAT(created_at, '%d/%m/%Y %H:%i:%s') as waktu,
            suhu,
            kelembapan,
            tds,
            baterai,
            CASE WHEN pump_status = 1 THEN 'AKTIF' ELSE 'NONAKTIF' END as pompa
          FROM sensor_data 
          ORDER BY created_at DESC";

$result = mysqli_query($conn, $query);
$data = [];

while ($row = mysqli_fetch_assoc($result)) {
    $data[] = $row;
}

if (count($data) > 0) {
    $csv = "Waktu,Suhu (°C),Kelembapan (%),TDS (ppm),Baterai (%),Pompa\n";
    foreach ($data as $row) {
        $csv .= $row['waktu'] . ',' . $row['suhu'] . ',' . $row['kelembapan'] . ',' . 
                $row['tds'] . ',' . $row['baterai'] . ',' . $row['pompa'] . "\n";
    }
    
    echo json_encode([
        'success' => true,
        'csv' => $csv,
        'total' => count($data)
    ]);
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Tidak ada data untuk diekspor'
    ]);
}
?>