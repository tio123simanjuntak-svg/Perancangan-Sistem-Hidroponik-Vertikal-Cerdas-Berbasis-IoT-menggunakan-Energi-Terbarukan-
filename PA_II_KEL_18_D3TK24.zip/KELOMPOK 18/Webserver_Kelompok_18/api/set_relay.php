<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

require_once 'db.php';

$relay_state = isset($_POST['state']) ? intval($_POST['state']) : 0;

$sql = "UPDATE sensor_data SET relay_control = ? ORDER BY id DESC LIMIT 1";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $relay_state);

if ($stmt->execute()) {
    echo json_encode([
        'status' => 'success',
        'message' => 'Relay set to ' . ($relay_state ? 'ON' : 'OFF'),
        'data' => ['relay_state' => $relay_state]
    ]);
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Failed to set relay'
    ]);
}

$stmt->close();
$conn->close();
?>