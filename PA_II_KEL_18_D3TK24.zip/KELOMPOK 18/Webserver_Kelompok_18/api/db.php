<?php
// ==============================================
// DATABASE CONFIGURATION
// ==============================================

$host = 'localhost';
$username = 'root';
$password = '';  // Kosongkan jika pakai XAMPP default
$database = 'sensor_db';  // Nama database yang benar

// Buat koneksi
$conn = mysqli_connect($host, $username, $password, $database);

// Cek koneksi
if (!$conn) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

// Set charset
mysqli_set_charset($conn, "utf8mb4");
?>