<?php
// ==============================================
// API SOLAR STATUS
// ==============================================

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

require_once '../config/database.php';

$query = "SELECT 
            arus_surya, 
            tegangan_surya, 
            baterai,
            battery_voltage,
            created_at 
          FROM sensor_data 
          ORDER BY created_at DESC 
          LIMIT 1";

$result = mysqli_query($conn, $query);

if ($result && mysqli_num_rows($result) > 0) {
    $data = mysqli_fetch_assoc($result);
    
    $solar_status = ($data['arus_surya'] > 1.0) ? 'MENGISI' : 'IDLE';
    
    echo json_encode([
        'success' => true,
        'solar_status' => $solar_status,
        'arus_surya' => $data['arus_surya'],
        'tegangan_surya' => $data['tegangan_surya'],
        'baterai' => $data['baterai'],
        'battery_voltage' => $data['battery_voltage']
    ]);
} else {
    echo json_encode([
        'success' => true,
        'solar_status' => 'IDLE',
        'arus_surya' => 0.00,
        'tegangan_surya' => 0.00,
        'baterai' => 0,
        'battery_voltage' => 0.00
    ]);
}
?>