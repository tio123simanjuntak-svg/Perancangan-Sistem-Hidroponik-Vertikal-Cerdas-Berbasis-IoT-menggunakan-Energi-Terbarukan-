<?php
// ==============================================
// API: GET HISTORY DATA
// dashboard/api/get_history.php
// ==============================================

require_once '../config/database.php';
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$page     = isset($_GET['page'])     ? max(1, (int)$_GET['page'])     : 1;
$per_page = isset($_GET['per_page']) ? max(1, (int)$_GET['per_page']) : 10;
$date     = isset($_GET['date'])     ? trim($_GET['date'])             : '';
$offset   = ($page - 1) * $per_page;

// Build WHERE clause
$where  = '';
$params = [];
$types  = '';

if ($date !== '') {
    $where    = 'WHERE DATE(created_at) = ?';
    $params[] = $date;
    $types   .= 's';
}

// Total rows
$count_sql = "SELECT COUNT(*) AS total FROM sensor_data $where";
$stmt = $conn->prepare($count_sql);
if ($params) $stmt->bind_param($types, ...$params);
$stmt->execute();
$total = (int)$stmt->get_result()->fetch_assoc()['total'];
$stmt->close();

if ($total === 0) {
    echo json_encode(['data' => [], 'total' => 0]);
    exit;
}

// Fetch rows
$data_sql = "SELECT 
                suhu,
                kelembapan,
                tds,
                baterai,
                pump_status,
                DATE_FORMAT(created_at, '%d/%m/%Y %H:%i:%s') AS created_at
             FROM sensor_data
             $where
             ORDER BY id DESC
             LIMIT ? OFFSET ?";

$data_params   = array_merge($params, [$per_page, $offset]);
$data_types    = $types . 'ii';

$stmt = $conn->prepare($data_sql);
$stmt->bind_param($data_types, ...$data_params);
$stmt->execute();
$rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

echo json_encode(['data' => $rows, 'total' => $total]);