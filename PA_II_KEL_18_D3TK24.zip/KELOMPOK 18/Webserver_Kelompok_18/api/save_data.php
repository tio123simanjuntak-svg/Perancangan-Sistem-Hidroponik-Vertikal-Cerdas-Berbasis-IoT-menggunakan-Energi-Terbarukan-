<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

require_once 'db.php';

// Ambil data dari POST (dari ESP32)
$temperature = isset($_POST['temperature']) ? floatval($_POST['temperature']) : 0;
$humidity = isset($_POST['humidity']) ? floatval($_POST['humidity']) : 0;
$tds_ppm = isset($_POST['tds_ppm']) ? intval($_POST['tds_ppm']) : 0;
$ph_level = isset($_POST['ph_level']) ? floatval($_POST['ph_level']) : 0;
$water_temperature = isset($_POST['water_temperature']) ? floatval($_POST['water_temperature']) : 0;
$water_level = isset($_POST['water_level']) ? intval($_POST['water_level']) : 0;
$battery_voltage = isset($_POST['battery_voltage']) ? floatval($_POST['battery_voltage']) : 0;
$battery_level = isset($_POST['battery_level']) ? intval($_POST['battery_level']) : 0;
$solar_current = isset($_POST['solar_current']) ? floatval($_POST['solar_current']) : 0;
$solar_voltage = isset($_POST['solar_voltage']) ? floatval($_POST['solar_voltage']) : 0;
$pump_status = isset($_POST['pump_status']) ? intval($_POST['pump_status']) : 0;
$fan_status = isset($_POST['fan_status']) ? intval($_POST['fan_status']) : 0;
$light_status = isset($_POST['light_status']) ? intval($_POST['light_status']) : 0;
$relay_control = isset($_POST['relay_control']) ? intval($_POST['relay_control']) : 0;

// Validasi data
if ($temperature == 0 && $humidity == 0 && $tds_ppm == 0) {
    response('error', 'No valid data received');
}

// Insert ke database
$sql = "INSERT INTO sensor_data (
    temperature, humidity, tds_ppm, ph_level, 
    water_temperature, water_level, 
    battery_voltage, battery_level, 
    solar_current, solar_voltage,
    pump_status, fan_status, light_status, relay_control
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param(
    "ddiddidddiiiii",
    $temperature,
    $humidity,
    $tds_ppm,
    $ph_level,
    $water_temperature,
    $water_level,
    $battery_voltage,
    $battery_level,
    $solar_current,
    $solar_voltage,
    $pump_status,
    $fan_status,
    $light_status,
    $relay_control
);

if ($stmt->execute()) {
    response('success', 'Data saved successfully', [
        'id' => $stmt->insert_id,
        'temperature' => $temperature,
        'humidity' => $humidity,
        'tds_ppm' => $tds_ppm
    ]);
} else {
    response('error', 'Failed to save data: ' . $stmt->error);
}

$stmt->close();
$conn->close();
?>