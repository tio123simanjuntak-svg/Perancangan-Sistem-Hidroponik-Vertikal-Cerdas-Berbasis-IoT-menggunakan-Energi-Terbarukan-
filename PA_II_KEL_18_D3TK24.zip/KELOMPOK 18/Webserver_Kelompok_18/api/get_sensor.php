<?php
// ==============================================
// API INPUT SENSOR DATA
// ==============================================

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

require_once '../config/database.php';

// Ambil data dari POST
$suhu = isset($_POST['suhu']) ? floatval($_POST['suhu']) : 25.0;
$kelembapan = isset($_POST['kelembapan']) ? floatval($_POST['kelembapan']) : 75.0;
$tds = isset($_POST['tds']) ? intval($_POST['tds']) : 750;
$water_level = isset($_POST['water_level']) ? intval($_POST['water_level']) : 80;
$battery_voltage = isset($_POST['battery_voltage']) ? floatval($_POST['battery_voltage']) : 12.50;
$baterai = isset($_POST['baterai']) ? intval($_POST['baterai']) : 75;
$arus_surya = isset($_POST['arus_surya']) ? floatval($_POST['arus_surya']) : 1.50;
$tegangan_surya = isset($_POST['tegangan_surya']) ? floatval($_POST['tegangan_surya']) : 13.20;
$pump_status = isset($_POST['pump_status']) ? intval($_POST['pump_status']) : 0;

// Validasi data
if ($suhu < 15 || $suhu > 45) {
    echo json_encode(['success' => false, 'message' => 'Suhu tidak valid (15-45°C)']);
    exit;
}

if ($kelembapan < 20 || $kelembapan > 100) {
    echo json_encode(['success' => false, 'message' => 'Kelembapan tidak valid (20-100%)']);
    exit;
}

if ($tds < 200 || $tds > 1500) {
    echo json_encode(['success' => false, 'message' => 'TDS tidak valid (200-1500 ppm)']);
    exit;
}

if ($baterai < 0 || $baterai > 100) {
    echo json_encode(['success' => false, 'message' => 'Baterai tidak valid (0-100%)']);
    exit;
}

// Query insert
$query = "INSERT INTO sensor_data (
    suhu, kelembapan, tds, water_level, 
    battery_voltage, baterai, arus_surya, tegangan_surya, 
    pump_status, created_at
) VALUES (
    '$suhu', '$kelembapan', '$tds', '$water_level',
    '$battery_voltage', '$baterai', '$arus_surya', '$tegangan_surya',
    '$pump_status', NOW()
)";

if (mysqli_query($conn, $query)) {
    $id = mysqli_insert_id($conn);
    echo json_encode([
        'success' => true,
        'message' => 'Data berhasil disimpan',
        'id' => $id,
        'data' => [
            'suhu' => $suhu,
            'kelembapan' => $kelembapan,
            'tds' => $tds,
            'water_level' => $water_level,
            'baterai' => $baterai,
            'pump_status' => $pump_status
        ]
    ]);
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Gagal menyimpan data: ' . mysqli_error($conn)
    ]);
}
?>