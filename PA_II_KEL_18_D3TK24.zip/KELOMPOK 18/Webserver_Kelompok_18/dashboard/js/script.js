// ==============================================
// JAVASCRIPT FOR HIDROPONIK MONITORING
// ==============================================

let currentPage = 1;
let totalPages = 1;
const perPage = 10;

// ============================================
// DATA REALTIME DUMMY
// ============================================

// State untuk data realtime
let realtimeData = {
    suhu: 25.0,
    kelembapan: 75.0,
    tds: 750,
    water_level: 80,
    battery_voltage: 12.50,
    baterai: 75,
    arus_surya: 1.50,
    tegangan_surya: 13.20,
    pump_status: 0
};

// Fungsi untuk generate data realtime berdasarkan jam
function generateRealtimeData() {
    const now = new Date();
    const hour = now.getHours();
    const minute = now.getMinutes();
    const second = now.getSeconds();
    
    // ============================================
    // POLA DATA BERDASARKAN JAM (REALISTIS)
    // ============================================
    
    let baseTemp, baseHumid, baseTDS, baseBattery, baseVoltage, baseSolarCurrent, baseSolarVoltage;
    let pumpStatus = 0;
    
    // 00:00 - 04:00 (Dini Hari - Paling Dingin)
    if (hour >= 0 && hour < 4) {
        baseTemp = 20.0 + (Math.random() * 2.5);
        baseHumid = 85.0 + (Math.random() * 5.0);
        baseTDS = 780 + Math.floor(Math.random() * 30);
        baseBattery = 30 + Math.floor(Math.random() * 20);
        baseVoltage = 11.3 + (Math.random() * 0.5);
        baseSolarCurrent = 0.0 + (Math.random() * 0.1);
        baseSolarVoltage = 11.0 + (Math.random() * 0.5);
        pumpStatus = 0;
    }
    // 05:00 - 07:00 (Pagi - Sejuk, Pompa ON)
    else if (hour >= 5 && hour < 7) {
        baseTemp = 22.0 + (Math.random() * 3.0);
        baseHumid = 82.0 + (Math.random() * 6.0);
        baseTDS = 765 + Math.floor(Math.random() * 30);
        baseBattery = 45 + Math.floor(Math.random() * 20);
        baseVoltage = 11.8 + (Math.random() * 0.6);
        baseSolarCurrent = 0.3 + (Math.random() * 1.0);
        baseSolarVoltage = 12.0 + (Math.random() * 1.0);
        pumpStatus = (hour === 6 || hour === 7) ? 1 : 0;
    }
    // 08:00 - 10:00 (Pagi - Hangat, Pompa ON di jam 8)
    else if (hour >= 8 && hour < 10) {
        baseTemp = 25.0 + (Math.random() * 4.0);
        baseHumid = 72.0 + (Math.random() * 8.0);
        baseTDS = 750 + Math.floor(Math.random() * 35);
        baseBattery = 60 + Math.floor(Math.random() * 20);
        baseVoltage = 12.3 + (Math.random() * 0.7);
        baseSolarCurrent = 2.0 + (Math.random() * 2.0);
        baseSolarVoltage = 13.0 + (Math.random() * 1.0);
        pumpStatus = (hour === 8) ? 1 : 0;
    }
    // 11:00 - 14:00 (Siang - Panas, Pompa OFF)
    else if (hour >= 11 && hour < 14) {
        baseTemp = 30.0 + (Math.random() * 4.5);
        baseHumid = 55.0 + (Math.random() * 15.0);
        baseTDS = 690 + Math.floor(Math.random() * 50);
        baseBattery = 80 + Math.floor(Math.random() * 15);
        baseVoltage = 13.5 + (Math.random() * 1.2);
        baseSolarCurrent = 4.0 + (Math.random() * 1.5);
        baseSolarVoltage = 14.5 + (Math.random() * 1.5);
        pumpStatus = 0;
    }
    // 15:00 - 17:00 (Sore - Mulai Dingin, Pompa ON di jam 17)
    else if (hour >= 15 && hour < 17) {
        baseTemp = 26.0 + (Math.random() * 4.0);
        baseHumid = 68.0 + (Math.random() * 12.0);
        baseTDS = 735 + Math.floor(Math.random() * 35);
        baseBattery = 75 + Math.floor(Math.random() * 15);
        baseVoltage = 12.8 + (Math.random() * 0.8);
        baseSolarCurrent = 2.5 + (Math.random() * 2.0);
        baseSolarVoltage = 13.5 + (Math.random() * 1.0);
        pumpStatus = (hour === 17) ? 1 : 0;
    }
    // 18:00 - 20:00 (Malam - Dingin)
    else if (hour >= 18 && hour < 20) {
        baseTemp = 23.0 + (Math.random() * 3.0);
        baseHumid = 78.0 + (Math.random() * 8.0);
        baseTDS = 755 + Math.floor(Math.random() * 30);
        baseBattery = 65 + Math.floor(Math.random() * 20);
        baseVoltage = 12.3 + (Math.random() * 0.6);
        baseSolarCurrent = 0.5 + (Math.random() * 1.0);
        baseSolarVoltage = 12.0 + (Math.random() * 1.0);
        pumpStatus = 0;
    }
    // 21:00 - 23:00 (Malam - Dingin)
    else if (hour >= 21 && hour < 24) {
        baseTemp = 20.0 + (Math.random() * 3.0);
        baseHumid = 82.0 + (Math.random() * 8.0);
        baseTDS = 775 + Math.floor(Math.random() * 30);
        baseBattery = 35 + Math.floor(Math.random() * 25);
        baseVoltage = 11.5 + (Math.random() * 0.5);
        baseSolarCurrent = 0.0 + (Math.random() * 0.2);
        baseSolarVoltage = 11.0 + (Math.random() * 0.5);
        pumpStatus = 0;
    }
    
    // ============================================
    // VARIASI NATURAL (Tambahan Random)
    // ============================================
    
    // Tambah sedikit variasi agar data tidak monoton
    const variation = (Math.random() - 0.5) * 0.6;
    
    // Water Level: turun saat siang (penguapan), naik saat malam
    let waterLevel;
    if (hour >= 11 && hour <= 15) {
        waterLevel = 65 + Math.floor(Math.random() * 20);
    } else if (hour >= 6 && hour <= 9) {
        waterLevel = 78 + Math.floor(Math.random() * 15);
    } else {
        waterLevel = 75 + Math.floor(Math.random() * 18);
    }
    
    // Update data realtime
    realtimeData = {
        suhu: Math.round((baseTemp + variation) * 10) / 10,
        kelembapan: Math.round((baseHumid + (Math.random() - 0.5) * 4) * 10) / 10,
        tds: Math.round(baseTDS + (Math.random() - 0.5) * 20),
        water_level: waterLevel,
        battery_voltage: Math.round((baseVoltage + (Math.random() - 0.5) * 0.3) * 100) / 100,
        baterai: Math.round(baseBattery + (Math.random() - 0.5) * 8),
        arus_surya: Math.round((baseSolarCurrent + (Math.random() - 0.5) * 0.5) * 100) / 100,
        tegangan_surya: Math.round((baseSolarVoltage + (Math.random() - 0.5) * 0.5) * 100) / 100,
        pump_status: pumpStatus
    };
    
    // Pastikan nilai dalam batas wajar
    realtimeData.suhu = Math.max(18, Math.min(36, realtimeData.suhu));
    realtimeData.kelembapan = Math.max(45, Math.min(95, realtimeData.kelembapan));
    realtimeData.tds = Math.max(650, Math.min(850, realtimeData.tds));
    realtimeData.baterai = Math.max(20, Math.min(98, realtimeData.baterai));
    realtimeData.water_level = Math.max(50, Math.min(95, realtimeData.water_level));
    realtimeData.arus_surya = Math.max(0, Math.min(6, realtimeData.arus_surya));
    realtimeData.tegangan_surya = Math.max(10.5, Math.min(17, realtimeData.tegangan_surya));
    realtimeData.battery_voltage = Math.max(10.5, Math.min(14.8, realtimeData.battery_voltage));
    
    return realtimeData;
}

// ============================================
// UPDATE UI DENGAN DATA REALTIME
// ============================================

function updateRealtimeUI(data) {
    // Update Suhu Udara
    const tempEl = document.getElementById('temp-value');
    const tempStatus = document.getElementById('temp-status');
    if (tempEl) {
        tempEl.innerText = data.suhu + '°C';
        if (data.suhu > 30) {
            tempStatus.innerText = 'Panas';
            tempStatus.style.color = '#ef4444';
        } else if (data.suhu > 25) {
            tempStatus.innerText = 'Hangat';
            tempStatus.style.color = '#f59e0b';
        } else {
            tempStatus.innerText = 'Normal';
            tempStatus.style.color = '#22c55e';
        }
    }
    
    // Update Kelembapan
    const humidEl = document.getElementById('humid-value');
    const humidStatus = document.getElementById('humid-status');
    if (humidEl) {
        humidEl.innerText = data.kelembapan + '%';
        if (data.kelembapan > 80) {
            humidStatus.innerText = 'Lembab';
            humidStatus.style.color = '#3b82f6';
        } else if (data.kelembapan > 60) {
            humidStatus.innerText = 'Normal';
            humidStatus.style.color = '#22c55e';
        } else {
            humidStatus.innerText = 'Kering';
            humidStatus.style.color = '#f59e0b';
        }
    }
    
    // Update TDS
    const tdsEl = document.getElementById('tds-value');
    const tdsStatus = document.getElementById('tds-status');
    if (tdsEl) {
        tdsEl.innerText = data.tds + ' ppm';
        if (data.tds > 900) {
            tdsStatus.innerText = 'Tinggi';
            tdsStatus.style.color = '#ef4444';
        } else if (data.tds > 500) {
            tdsStatus.innerText = 'Normal';
            tdsStatus.style.color = '#22c55e';
        } else {
            tdsStatus.innerText = 'Rendah';
            tdsStatus.style.color = '#f59e0b';
        }
    }
    
    // Update Baterai
    const batteryLevel = document.getElementById('battery-level');
    const batteryFill = document.getElementById('battery-fill');
    const batteryVoltage = document.getElementById('battery-voltage');
    if (batteryLevel) {
        batteryLevel.innerText = data.baterai + '%';
        batteryFill.style.width = data.baterai + '%';
        if (data.baterai > 70) {
            batteryFill.style.background = '#22c55e';
        } else if (data.baterai > 40) {
            batteryFill.style.background = '#f59e0b';
        } else {
            batteryFill.style.background = '#ef4444';
        }
    }
    if (batteryVoltage) {
        batteryVoltage.innerText = data.battery_voltage + ' V';
    }
    
    // Update Solar Panel
    const solarCurrent = document.getElementById('solar-current');
    const solarVoltage = document.getElementById('solar-voltage');
    if (solarCurrent) {
        solarCurrent.innerText = data.arus_surya + ' A';
    }
    if (solarVoltage) {
        solarVoltage.innerText = data.tegangan_surya + ' V';
    }
    
    // Update Nutrisi
    const nutrientTds = document.getElementById('nutrient-tds');
    if (nutrientTds) {
        nutrientTds.innerText = data.tds + ' ppm';
    }
    
    // Update Status Pompa
    const pumpStatus = document.getElementById('pump-status-text');
    if (pumpStatus) {
        if (data.pump_status === 1) {
            pumpStatus.innerText = 'AKTIF';
            pumpStatus.className = 'pump-status active';
        } else {
            pumpStatus.innerText = 'NONAKTIF';
            pumpStatus.className = 'pump-status inactive';
        }
    }
}

// ============================================
// AUTO UPDATE REALTIME (SETIAP 1 DETIK)
// ============================================

function startRealtimeUpdate() {
    // Update pertama kali
    const data = generateRealtimeData();
    updateRealtimeUI(data);
    
    // Update setiap 1 detik
    setInterval(() => {
        const newData = generateRealtimeData();
        updateRealtimeUI(newData);
    }, 1000);
}

// ============================================
// FUNGSI LAINNYA (TETAP SAMA)
// ============================================

// Fungsi untuk memuat riwayat data
function loadHistory() {
    const dateFilter = document.getElementById('date-filter')?.value || '';
    const tbody = document.getElementById('history-body');
    
    tbody.innerHTML = '<tr><td colspan="6" class="loading-text"><i class="fas fa-spinner fa-spin"></i> Memuat data...</td></tr>';
    
    let url = `/api/get_history.php?page=${currentPage}&limit=${perPage}`;
    if (dateFilter) {
        url += `&date=${dateFilter}`;
    }
    
    fetch(url)
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                tbody.innerHTML = `<tr><td colspan="6" class="loading-text">${data.error}</td></tr>`;
                return;
            }
            
            if (data.data.length === 0) {
                tbody.innerHTML = '<tr><td colspan="6" class="loading-text">Tidak ada data untuk tanggal ini</td></tr>';
                document.getElementById('total-records').innerText = 'Total: 0 data';
                return;
            }
            
            let html = '';
            data.data.forEach(row => {
                const statusClass = row.pompa === 'AKTIF' ? 'active' : 'inactive';
                html += `
                    <tr>
                        <td>${row.waktu}</td>
                        <td>${row.suhu}</td>
                        <td>${row.kelembaban}</td>
                        <td>${row.tds}</td>
                        <td>${row.baterai}</td>
                        <td>
                            <span class="pump-status ${statusClass}">
                                ${row.pompa}
                            </span>
                        </td>
                    </tr>
                `;
            });
            
            tbody.innerHTML = html;
            
            totalPages = data.total_pages || 1;
            document.getElementById('page-info').innerText = `Halaman ${currentPage} dari ${totalPages}`;
            document.getElementById('total-records').innerText = `Total: ${data.total} data`;
            
            document.querySelector('.page-btn:first-child').disabled = currentPage <= 1;
            document.querySelector('.page-btn:last-child').disabled = currentPage >= totalPages;
        })
        .catch(error => {
            console.error('Error loading history:', error);
            tbody.innerHTML = '<tr><td colspan="6" class="loading-text">Error memuat data</td></tr>';
        });
}

// Pagination functions
function prevPage() {
    if (currentPage > 1) {
        currentPage--;
        loadHistory();
    }
}

function nextPage() {
    if (currentPage < totalPages) {
        currentPage++;
        loadHistory();
    }
}

// Fungsi kontrol pompa
function pumpControl(action, duration = null) {
    const feedback = document.getElementById('feedback-text');
    
    let message = '';
    if (action === 'on') {
        message = duration ? `Pompa dinyalakan selama ${duration} detik` : 'Pompa dinyalakan';
        feedback.innerText = message;
        
        // Update status pompa di UI
        realtimeData.pump_status = 1;
        updateRealtimeUI(realtimeData);
        
        fetch('/api/pump_control.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'on', duration: duration })
        })
        .then(response => response.json())
        .then(data => {
            showNotification('success', data.message || 'Pompa berhasil dinyalakan');
            loadHistory();
        })
        .catch(error => {
            showNotification('error', 'Gagal mengontrol pompa');
        });
        
    } else if (action === 'off') {
        message = 'Pompa dimatikan';
        feedback.innerText = message;
        
        // Update status pompa di UI
        realtimeData.pump_status = 0;
        updateRealtimeUI(realtimeData);
        
        fetch('/api/pump_control.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'off' })
        })
        .then(response => response.json())
        .then(data => {
            showNotification('success', data.message || 'Pompa berhasil dimatikan');
            loadHistory();
        })
        .catch(error => {
            showNotification('error', 'Gagal mengontrol pompa');
        });
    }
}

// Fungsi notifikasi
function showNotification(type, message) {
    const notif = document.getElementById('notification');
    const icon = document.getElementById('notif-icon');
    const text = document.getElementById('notif-text');
    
    notif.className = 'notification';
    if (type === 'success') {
        notif.classList.add('success');
        icon.className = 'fas fa-check-circle';
    } else if (type === 'error') {
        notif.classList.add('error');
        icon.className = 'fas fa-exclamation-circle';
    } else {
        notif.classList.add('info');
        icon.className = 'fas fa-info-circle';
    }
    
    text.innerText = message;
    notif.style.display = 'block';
    notif.style.opacity = '1';
    
    clearTimeout(notif._timeout);
    notif._timeout = setTimeout(() => {
        notif.style.opacity = '0';
        setTimeout(() => {
            notif.style.display = 'none';
        }, 300);
    }, 3000);
}

// Navigasi
function navigateTo(page) {
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
    });
    if (event && event.target) {
        event.target.closest('.nav-item').classList.add('active');
    }
    
    switch(page) {
        case 'dashboard':
            break;
        case 'history':
            document.querySelector('.history-section').scrollIntoView({ behavior: 'smooth' });
            loadHistory();
            break;
        case 'input':
            document.getElementById('input-section').scrollIntoView({ behavior: 'smooth' });
            break;
        case 'analisis':
            showNotification('info', 'Fitur analisis sedang dikembangkan');
            break;
        case 'kontrol':
            showNotification('info', 'Fitur kontrol sedang dikembangkan');
            break;
        case 'pengaturan':
            showNotification('info', 'Fitur pengaturan sedang dikembangkan');
            break;
    }
}

// Modal
function showDetail(title, value) {
    document.getElementById('modal-title').innerText = title;
    document.getElementById('modal-value').innerHTML = `<strong>Nilai:</strong> ${value}`;
    document.getElementById('detail-modal').style.display = 'block';
}

function closeModal() {
    document.getElementById('detail-modal').style.display = 'none';
}

// Tutup modal jika klik di luar
window.onclick = function(event) {
    const modal = document.getElementById('detail-modal');
    if (event.target == modal) {
        modal.style.display = 'none';
    }
}

// Update clock
function updateClock() {
    const now = new Date();
    const options = { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    };
    const clock = document.getElementById('clock-display');
    if (clock) {
        clock.innerText = now.toLocaleDateString('id-ID', options);
    }
}

// ============================================
// INITIALISASI
// ============================================

document.addEventListener('DOMContentLoaded', function() {
    // Start realtime update setiap 1 detik
    startRealtimeUpdate();
    
    // Load history
    loadHistory();
    
    // Update clock
    updateClock();
    setInterval(updateClock, 1000);
    
    // Auto refresh history setiap 30 detik
    setInterval(loadHistory, 30000);
});

// ============================================
// SUBMIT FORM SENSOR
// ============================================

function submitSensorData(event) {
    event.preventDefault();
    
    const form = document.getElementById('sensor-form');
    const formData = new FormData(form);
    
    fetch('/api/input_sensor.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showAlert('success', 'Data berhasil disimpan!');
            form.reset();
            loadHistory();
            showNotification('success', 'Data sensor berhasil ditambahkan!');
        } else {
            showAlert('error', data.message || 'Gagal menyimpan data');
        }
    })
    .catch(error => {
        showAlert('error', 'Terjadi kesalahan: ' + error.message);
    });
}

function generateRandomData() {
    const data = generateRealtimeData();
    
    document.getElementById('suhu').value = data.suhu;
    document.getElementById('kelembapan').value = data.kelembapan;
    document.getElementById('tds').value = data.tds;
    document.getElementById('water_level').value = data.water_level;
    document.getElementById('baterai').value = data.baterai;
    document.getElementById('battery_voltage').value = data.battery_voltage;
    document.getElementById('arus_surya').value = data.arus_surya;
    document.getElementById('tegangan_surya').value = data.tegangan_surya;
    document.getElementById('pump_status').value = data.pump_status;
    
    showNotification('info', 'Data random telah diisi, klik Simpan untuk menyimpan');
}

function generateBatchData() {
    if (!confirm('Generate 10 data random sekaligus?')) return;
    
    fetch('/api/generate_batch.php', {
        method: 'POST'
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showAlert('success', 'Berhasil generate ' + data.total + ' data!');
            loadHistory();
            showNotification('success', data.total + ' data berhasil digenerate!');
        } else {
            showAlert('error', data.message || 'Gagal generate data');
        }
    })
    .catch(error => {
        showAlert('error', 'Terjadi kesalahan: ' + error.message);
    });
}

function showAlert(type, message) {
    const alert = document.getElementById('alert-message');
    const text = document.getElementById('alert-text');
    
    alert.className = 'alert-success show';
    if (type === 'error') {
        alert.style.background = '#fee2e2';
        alert.style.color = '#991b1b';
    } else {
        alert.style.background = '#dcfce7';
        alert.style.color = '#166534';
    }
    
    text.textContent = message;
    
    setTimeout(() => {
        alert.className = 'alert-success';
    }, 5000);
}