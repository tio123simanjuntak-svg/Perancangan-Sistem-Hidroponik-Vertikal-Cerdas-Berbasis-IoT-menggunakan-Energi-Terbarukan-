// ==============================================
// HIDROPONIK APP - MAIN JAVASCRIPT
// ==============================================

const API_URL = '../api/';
let pumpTimerInterval = null;
let pumpSeconds = 0;
let isPumpRunning = false;

// ==============================================
// NAVIGASI
// ==============================================
function navigateTo(page) {
    // Update active nav
    document.querySelectorAll('.nav-item').forEach(el => el.classList.remove('active'));
    event.target.closest('.nav-item').classList.add('active');
    
    // Tampilkan notifikasi
    showNotification('info', 'Navigasi ke: ' + page.charAt(0).toUpperCase() + page.slice(1));
    
    // Scroll ke atas
    document.getElementById('main-content').scrollTop = 0;
}

// ==============================================
// SHOW DETAIL MODAL
// ==============================================
function showDetail(title, value) {
    document.getElementById('modal-title').textContent = title;
    document.getElementById('modal-value').textContent = 'Nilai: ' + value;
    document.getElementById('detail-modal').classList.add('show');
}

function closeModal() {
    document.getElementById('detail-modal').classList.remove('show');
}

// Click outside modal to close
document.addEventListener('click', function(e) {
    const modal = document.getElementById('detail-modal');
    if (e.target === modal) {
        modal.classList.remove('show');
    }
});

// ==============================================
// PUMP CONTROL
// ==============================================
function pumpControl(action, duration = 0) {
    const buttons = document.querySelectorAll('.btn');
    buttons.forEach(btn => btn.disabled = true);
    
    const feedback = document.getElementById('control-feedback');
    const feedbackText = document.getElementById('feedback-text');
    
    const formData = new FormData();
    formData.append('action', action);
    if (duration > 0) {
        formData.append('duration', duration);
    }
    
    feedback.className = 'control-feedback';
    feedbackText.textContent = 'Memproses permintaan...';
    
    fetch(API_URL + 'pump_control.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            feedback.className = 'control-feedback success';
            feedbackText.textContent = data.message + (duration > 0 ? ` (${duration} detik)` : '');
            
            updatePumpStatus(action === 'on');
            
            showNotification(
                'success',
                action === 'on' ? 'Pompa berhasil dinyalakan' : 'Pompa berhasil dimatikan'
            );
            
            if (duration > 0 && action === 'on') {
                startPumpTimer(duration);
            }
            
            setTimeout(() => {
                refreshAllData();
            }, 1000);
        } else {
            feedback.className = 'control-feedback error';
            feedbackText.textContent = 'Gagal: ' + data.message;
            showNotification('error', 'Gagal mengontrol pompa');
        }
    })
    .catch(error => {
        feedback.className = 'control-feedback error';
        feedbackText.textContent = 'Error: ' + error.message;
        showNotification('error', 'Terjadi kesalahan sistem');
    })
    .finally(() => {
        buttons.forEach(btn => btn.disabled = false);
    });
}

// ==============================================
// UPDATE PUMP STATUS
// ==============================================
function updatePumpStatus(isOn) {
    const statusText = document.getElementById('pump-status-text');
    const badge = document.querySelector('.status-badge:last-child');
    
    if (isOn) {
        statusText.textContent = 'AKTIF';
        statusText.className = 'pump-status active';
        badge.className = 'status-badge success';
        badge.innerHTML = '<i class="fas fa-circle"></i> Pompa ON';
    } else {
        statusText.textContent = 'NONAKTIF';
        statusText.className = 'pump-status inactive';
        badge.className = 'status-badge danger';
        badge.innerHTML = '<i class="fas fa-circle"></i> Pompa OFF';
    }
}

// ==============================================
// PUMP TIMER
// ==============================================
function startPumpTimer(duration) {
    if (pumpTimerInterval) {
        clearInterval(pumpTimerInterval);
    }
    
    pumpSeconds = duration;
    isPumpRunning = true;
    updateTimerDisplay();
    
    pumpTimerInterval = setInterval(() => {
        pumpSeconds--;
        updateTimerDisplay();
        
        if (pumpSeconds <= 0) {
            clearInterval(pumpTimerInterval);
            pumpTimerInterval = null;
            isPumpRunning = false;
            document.getElementById('timer-display').textContent = '00:00';
            pumpControl('off');
        }
    }, 1000);
}

function updateTimerDisplay() {
    const minutes = Math.floor(pumpSeconds / 60);
    const seconds = pumpSeconds % 60;
    document.getElementById('timer-display').textContent = 
        String(minutes).padStart(2, '0') + ':' + String(seconds).padStart(2, '0');
}

// ==============================================
// NOTIFICATION
// ==============================================
function showNotification(type, message) {
    const notif = document.getElementById('notification');
    const icon = document.getElementById('notif-icon');
    const text = document.getElementById('notif-text');
    
    notif.className = 'notification';
    notif.classList.add(type);
    
    const icons = {
        success: 'fa-check-circle',
        error: 'fa-times-circle',
        info: 'fa-info-circle'
    };
    icon.className = 'fas ' + (icons[type] || icons.info);
    
    text.textContent = message;
    notif.classList.add('show');
    
    clearTimeout(window.notifTimeout);
    window.notifTimeout = setTimeout(() => {
        notif.classList.remove('show');
    }, 3500);
}

// ==============================================
// REFRESH ALL DATA - DENGAN SOLAR
// ==============================================
function refreshAllData() {
    getSensorData();
    getSolarStatus();
    loadHistory();
}

// ==============================================
// GET SENSOR DATA
// ==============================================
function getSensorData() {
    fetch(API_URL + 'get_sensor.php')
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                const sensor = data.data;
                
                document.getElementById('temp-value').textContent = sensor.temperature + '°C';
                document.getElementById('humid-value').textContent = sensor.humidity + '%';
                document.getElementById('tds-value').textContent = sensor.tds_ppm + ' ppm';
                document.getElementById('ph-value').textContent = sensor.ph_level;
                
                updateStatusLabel('temp', sensor.temperature, 'temperature');
                updateStatusLabel('humid', sensor.humidity, 'humidity');
                updateStatusLabel('tds', sensor.tds_ppm, 'tds');
                updateStatusLabel('ph', sensor.ph_level, 'ph');
                
                if (!isPumpRunning) {
                    updatePumpStatus(sensor.pump_status === 1);
                }
                
                const espBadge = document.querySelector('.status-badge:first-child');
                espBadge.className = 'status-badge success';
                espBadge.innerHTML = '<i class="fas fa-circle"></i> ESP32 ONLINE';
            }
        })
        .catch(error => console.log('Sensor error:', error));
}

// ==============================================
// UPDATE STATUS LABEL
// ==============================================
function updateStatusLabel(id, value, type) {
    const statusEl = document.getElementById(id + '-status');
    let text = '';
    
    switch(type) {
        case 'temperature':
            if (value > 32) text = 'Panas';
            else if (value > 28) text = 'Hangat';
            else if (value > 22) text = 'Normal';
            else text = 'Sejuk';
            break;
        case 'humidity':
            if (value > 80) text = 'Lembab';
            else if (value > 60) text = 'Normal';
            else text = 'Kering';
            break;
        case 'tds':
            if (value > 900) text = 'Tinggi';
            else if (value > 500) text = 'Normal';
            else text = 'Rendah';
            break;
        case 'ph':
            if (value > 7.5) text = 'Basa';
            else if (value > 6.0) text = 'Ideal';
            else text = 'Asam';
            break;
    }
    
    if (statusEl) statusEl.textContent = text;
}

// ==============================================
// GET SOLAR STATUS - REAL TIME
// ==============================================
function getSolarStatus() {
    fetch(API_URL + 'solar_status.php')
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                const solar = data.data;
                
                // Update solar
                document.getElementById('solar-current').textContent = solar.solar_current + ' A';
                document.getElementById('solar-voltage').textContent = solar.solar_voltage + ' V';
                
                // Update battery
                document.getElementById('battery-level').textContent = solar.battery_level + '%';
                document.getElementById('battery-voltage').textContent = solar.battery_voltage + ' V';
                
                const fill = document.getElementById('battery-fill');
                fill.style.width = solar.battery_level + '%';
                fill.style.background = solar.battery_level > 70 ? '#22c55e' : 
                                         solar.battery_level > 40 ? '#f59e0b' : '#ef4444';
                
                // Update solar status
                const statusEl = document.querySelector('.energy-status');
                if (statusEl) {
                    statusEl.textContent = solar.solar_status;
                    statusEl.className = 'energy-status ' + solar.status_color;
                }
                
                // Update nutrient from same API if available
                if (solar.nutrient) {
                    document.getElementById('nutrient-tds').textContent = solar.nutrient.tds + ' ppm';
                    document.getElementById('nutrient-ph').textContent = solar.nutrient.ph;
                    document.getElementById('nutrient-absorption').textContent = solar.nutrient.absorption + '%';
                }
            }
        })
        .catch(error => console.log('Solar error:', error));
}

// ==============================================
// LOAD HISTORY
// ==============================================
function loadHistory() {
    const tbody = document.getElementById('history-body');
    
    fetch(API_URL + 'get_history.php?limit=10')
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success' && data.data.length > 0) {
                let html = '';
                data.data.forEach(row => {
                    html += `
                        <tr>
                            <td>${formatTime(row.created_at)}</td>
                            <td>${row.temperature}°C</td>
                            <td>${row.humidity}%</td>
                            <td>${row.tds_ppm} ppm</td>
                            <td>${row.ph_level}</td>
                            <td>${row.battery_level}%</td>
                            <td>${row.pump_status ? 'ON' : 'OFF'}</td>
                        </tr>
                    `;
                });
                tbody.innerHTML = html;
            } else {
                tbody.innerHTML = `<tr><td colspan="7" class="loading-text">Belum ada data</td></tr>`;
            }
        })
        .catch(error => {
            tbody.innerHTML = `<tr><td colspan="7" class="loading-text">Gagal memuat data</td></tr>`;
        });
}

// ==============================================
// FORMAT TIME
// ==============================================
function formatTime(datetime) {
    const date = new Date(datetime);
    return date.toLocaleTimeString('id-ID', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    });
}

// ==============================================
// INITIALIZE
// ==============================================
document.addEventListener('DOMContentLoaded', () => {
    refreshAllData();
    
    // Auto refresh setiap 10 detik
    setInterval(refreshAllData, 10000);
    
    // Update clock
    updateClock();
    setInterval(updateClock, 1000);
});

// ==============================================
// UPDATE CLOCK
// ==============================================
function updateClock() {
    const now = new Date();
    const options = {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    };
    const timeEl = document.getElementById('clock-display');
    if (timeEl) {
        timeEl.textContent = now.toLocaleDateString('id-ID', options);
    }
}