<?php
// ==============================================
// HIDROPONIK VERTICAL MONITORING DASHBOARD
// ==============================================

require_once '../config/database.php';
require_once '../includes/functions.php';

// Get data
$sensor   = getLatestSensorData($conn);
$solar    = getSolarStatus();
$nutrient = getNutrientStatus();

// Status
$esp_status  = $sensor ? 'ONLINE' : 'OFFLINE';
$db_status   = 'CONNECTED';
$pump_status = $sensor ? $sensor['pump_status'] : 0;

// Waktu
date_default_timezone_set('Asia/Jakarta');
$current_time = date('l, d F Y H:i:s');

// Sensor values
$temperature  = $sensor ? $sensor['suhu']         : 25.0;
$humidity     = $sensor ? $sensor['kelembapan']    : 65.0;
$tds_ppm      = $sensor ? $sensor['tds']           : 750;
$water_level  = $sensor ? $sensor['water_level']   : 80;

// Solar values
$solar_status   = $solar['solar_status']   ?? 'IDLE';
$solar_current  = $solar['arus_surya']     ?? 1.50;
$solar_voltage  = $solar['tegangan_surya'] ?? 13.20;
$battery_level  = $solar['baterai']        ?? 75;
$battery_voltage= $solar['battery_voltage']?? 12.50;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hidroponik Vertikal Monitoring</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }

        body { font-family: 'Inter', sans-serif; background: #f8fafc; color: #1e293b; }

        .app-container { display: flex; min-height: 100vh; }

        /* ── SIDEBAR ── */
        .sidebar {
            width: 250px; background: #0f172a; color: #94a3b8;
            padding: 1.5rem 1rem; display: flex; flex-direction: column;
            position: fixed; height: 100vh; overflow-y: auto; z-index: 100;
        }
        .sidebar-brand {
            display: flex; align-items: center; gap: .75rem;
            padding-bottom: 1.5rem; border-bottom: 1px solid #1e293b; margin-bottom: 1.5rem;
        }
        .brand-icon {
            width: 40px; height: 40px; background: #22c55e; border-radius: 10px;
            display: flex; align-items: center; justify-content: center; font-size: 1.2rem; color: #fff;
        }
        .brand-text h2 { font-size: 1rem; font-weight: 700; color: #fff; }
        .brand-text span { font-size: .7rem; color: #94a3b8; }
        .sidebar-nav { flex: 1; }
        .sidebar-nav .nav-item {
            display: flex; align-items: center; gap: .75rem; padding: .7rem 1rem;
            border-radius: 8px; color: #94a3b8; text-decoration: none;
            transition: all .2s; cursor: pointer; margin-bottom: .25rem;
        }
        .sidebar-nav .nav-item:hover { background: #1e293b; color: #fff; }
        .sidebar-nav .nav-item.active { background: #1e293b; color: #22c55e; }
        .sidebar-nav .nav-item i { width: 20px; font-size: 1rem; }
        .sidebar-nav .nav-item span { font-size: .85rem; font-weight: 500; }
        .sidebar-footer { border-top: 1px solid #1e293b; padding-top: 1rem; margin-top: 1rem; }
        .system-status { display: flex; align-items: center; gap: .5rem; font-size: .8rem; color: #94a3b8; }
        .status-dot { width: 8px; height: 8px; border-radius: 50%; }
        .status-dot.online { background: #22c55e; animation: pulse-dot 2s infinite; }
        @keyframes pulse-dot { 0%,100%{opacity:1} 50%{opacity:.5} }
        .sidebar-version { font-size: .7rem; color: #475569; margin-top: .5rem; }

        /* ── MAIN ── */
        .main-content { margin-left: 250px; flex: 1; padding: 1.5rem 2rem 3rem; }

        .top-header {
            display: flex; justify-content: space-between; align-items: flex-start;
            flex-wrap: wrap; gap: 1rem; margin-bottom: 2rem;
        }
        .header-left h1 { font-size: 1.75rem; font-weight: 700; color: #0f172a; }
        .header-subtitle { color: #64748b; font-size: .9rem; }
        .header-right { display: flex; align-items: center; gap: 1.5rem; flex-wrap: wrap; }
        .header-time { font-size: .85rem; color: #475569; }
        .header-time i { margin-right: .5rem; color: #94a3b8; }
        .header-status { display: flex; gap: .75rem; flex-wrap: wrap; }
        .status-badge {
            display: inline-flex; align-items: center; gap: .35rem;
            padding: .25rem .75rem; border-radius: 20px; font-size: .7rem; font-weight: 600;
        }
        .status-badge.success { background: #dcfce7; color: #166534; }
        .status-badge.danger  { background: #fee2e2; color: #991b1b; }
        .status-badge i { font-size: .5rem; }

        /* ── STATS GRID ── */
        .stats-grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 1.5rem; margin-bottom: 2rem; }
        .stat-card {
            background: #fff; border-radius: 12px; padding: 1.5rem;
            display: flex; align-items: center; gap: 1rem;
            box-shadow: 0 1px 3px rgba(0,0,0,.08); cursor: pointer; transition: all .2s;
        }
        .stat-card:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,.12); }
        .stat-icon {
            width: 50px; height: 50px; border-radius: 12px;
            display: flex; align-items: center; justify-content: center; font-size: 1.5rem; flex-shrink: 0;
        }
        .stat-icon.temperature { background: #fef3c7; color: #d97706; }
        .stat-icon.humidity    { background: #dbeafe; color: #2563eb; }
        .stat-icon.tds         { background: #e0e7ff; color: #4f46e5; }
        .stat-info { flex: 1; }
        .stat-label { font-size: .7rem; text-transform: uppercase; letter-spacing: .5px; color: #94a3b8; font-weight: 600; }
        .stat-value { font-size: 1.75rem; font-weight: 700; color: #0f172a; display: block; }
        .stat-status { font-size: .75rem; font-weight: 500; }

        /* ── ENERGY SECTION ── */
        .energy-section { display: grid; grid-template-columns: repeat(3,1fr); gap: 1.5rem; margin-bottom: 2rem; }
        .energy-card {
            background: #fff; border-radius: 12px; padding: 1.5rem;
            box-shadow: 0 1px 3px rgba(0,0,0,.08); cursor: pointer; transition: all .2s;
        }
        .energy-card:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,.12); }
        .energy-header { display: flex; align-items: center; gap: .75rem; margin-bottom: .75rem; }
        .energy-header i { font-size: 1.25rem; }
        .energy-header h3 { font-size: .85rem; font-weight: 600; color: #475569; }
        .energy-card.solar   .energy-header i { color: #f59e0b; }
        .energy-card.battery .energy-header i { color: #2563eb; }
        .energy-card.nutrient.energy-header i { color: #22c55e; }
        .energy-status { display: inline-block; padding: .2rem .75rem; border-radius: 20px; font-size: .75rem; font-weight: 600; }
        .energy-status.charging { background: #dcfce7; color: #166534; }
        .energy-status.idle     { background: #f1f5f9; color: #64748b; }
        .energy-details { display: flex; gap: 1.5rem; margin-top: .5rem; }
        .energy-item { display: flex; flex-direction: column; }
        .energy-label { font-size: .65rem; color: #94a3b8; text-transform: uppercase; }
        .energy-value { font-size: 1.1rem; font-weight: 600; color: #0f172a; }
        .battery-level { font-size: 1.5rem; font-weight: 700; color: #0f172a; }
        .battery-bar { width: 100%; height: 8px; background: #e2e8f0; border-radius: 4px; overflow: hidden; margin: .5rem 0; }
        .battery-fill { height: 100%; border-radius: 4px; transition: width .5s ease; }
        .battery-voltage { font-size: .85rem; color: #64748b; }
        .nutrient-item { display: flex; justify-content: space-between; padding: .3rem 0; border-bottom: 1px solid #f1f5f9; }
        .nutrient-item:last-child { border-bottom: none; }
        .nutrient-label { font-size: .8rem; color: #64748b; }
        .nutrient-value { font-size: .85rem; font-weight: 600; color: #0f172a; }

        /* ── CONTROL ── */
        .control-section {
            background: #fff; border-radius: 12px; padding: 1.5rem;
            margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,.08);
        }
        .control-header {
            display: flex; justify-content: space-between; align-items: center;
            flex-wrap: wrap; gap: 1rem; margin-bottom: 1rem;
        }
        .control-header h3 { font-size: 1rem; font-weight: 600; color: #0f172a; }
        .control-header h3 i { margin-right: .5rem; color: #3b82f6; }
        .pump-indicator { display: flex; align-items: center; gap: .75rem; }
        .pump-label { font-size: .75rem; color: #94a3b8; }
        .pump-timer { font-size: .8rem; color: #64748b; }
        .pump-status { padding: .2rem .75rem; border-radius: 20px; font-size: .75rem; font-weight: 600; }
        .pump-status.active   { background: #dcfce7; color: #166534; }
        .pump-status.inactive { background: #fee2e2; color: #991b1b; }
        .control-buttons { display: flex; gap: .5rem; flex-wrap: wrap; margin: 1rem 0; }
        .btn {
            padding: .5rem 1rem; border: none; border-radius: 6px; font-weight: 500;
            cursor: pointer; transition: all .2s; display: flex; align-items: center;
            gap: .5rem; font-family: inherit; font-size: .85rem;
        }
        .btn:hover { transform: translateY(-1px); }
        .btn-timer   { background: #f1f5f9; color: #475569; }
        .btn-timer:hover { background: #e2e8f0; }
        .btn-primary { background: #22c55e; color: #fff; }
        .btn-primary:hover { background: #16a34a; }
        .btn-danger  { background: #ef4444; color: #fff; }
        .btn-danger:hover { background: #dc2626; }
        .control-feedback { padding: .75rem 1rem; background: #f8fafc; border-radius: 6px; font-size: .85rem; color: #64748b; }
        .control-feedback i { margin-right: .5rem; }

        /* ── HISTORY TABLE ── */
        .history-section {
            background: #fff; border-radius: 12px; padding: 1.5rem;
            box-shadow: 0 1px 3px rgba(0,0,0,.08);
        }
        .history-header {
            display: flex; justify-content: space-between; align-items: center;
            flex-wrap: wrap; gap: 1rem; margin-bottom: 1rem;
        }
        .history-header h3 { font-size: 1rem; font-weight: 600; color: #0f172a; }
        .history-header h3 i { margin-right: .5rem; color: #3b82f6; }
        .history-controls { display: flex; gap: .5rem; align-items: center; flex-wrap: wrap; }
        .date-filter {
            padding: .4rem .75rem; border: 1px solid #e2e8f0; border-radius: 6px;
            font-size: .8rem; font-family: inherit; color: #475569; background: #fff; cursor: pointer;
        }
        .btn-refresh {
            padding: .4rem 1rem; background: #f1f5f9; border: none; border-radius: 6px;
            cursor: pointer; font-size: .8rem; font-weight: 500; color: #475569;
            transition: all .2s; font-family: inherit;
        }
        .btn-refresh:hover { background: #e2e8f0; }
        .table-wrapper { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; font-size: .85rem; }
        table thead { background: #f8fafc; }
        table th { padding: .75rem 1rem; text-align: left; font-weight: 600; color: #475569; border-bottom: 2px solid #e2e8f0; }
        table td { padding: .75rem 1rem; border-bottom: 1px solid #f1f5f9; color: #1e293b; }
        table tbody tr:hover { background: #f8fafc; }
        .loading-text { text-align: center; color: #94a3b8; padding: 2rem !important; }

        /* ── PAGINATION ── */
        .pagination { display: flex; justify-content: center; gap: .5rem; margin-top: 1rem; flex-wrap: wrap; }
        .page-btn {
            padding: .35rem .75rem; border: 1px solid #e2e8f0; border-radius: 6px;
            background: #fff; cursor: pointer; font-size: .8rem; color: #475569;
            font-family: inherit; transition: all .2s;
        }
        .page-btn:hover { background: #f1f5f9; }
        .page-btn.active { background: #3b82f6; color: #fff; border-color: #3b82f6; }
        .page-btn:disabled { opacity: .4; cursor: not-allowed; }

        /* ── NOTIFICATION ── */
        .notification {
            position: fixed; top: 20px; right: 20px; padding: 1rem 1.5rem;
            border-radius: 10px; color: #fff; box-shadow: 0 4px 12px rgba(0,0,0,.15);
            z-index: 1000; display: none; max-width: 400px; animation: slideIn .3s ease;
        }
        @keyframes slideIn { from{transform:translateX(100%);opacity:0} to{transform:translateX(0);opacity:1} }
        .notification.success { background: #22c55e; }
        .notification.error   { background: #ef4444; }
        .notification.info    { background: #3b82f6; }
        .notification-content { display: flex; align-items: center; gap: .75rem; }

        /* ── MODAL ── */
        .modal {
            display: none; position: fixed; top:0; left:0; width:100%; height:100%;
            background: rgba(0,0,0,.5); z-index: 999; align-items: center; justify-content: center;
        }
        .modal-content {
            background: #fff; border-radius: 12px; padding: 1.5rem;
            max-width: 500px; width: 90%; animation: modalIn .3s ease;
        }
        @keyframes modalIn { from{transform:scale(.9);opacity:0} to{transform:scale(1);opacity:1} }
        .modal-header { display: flex; justify-content: space-between; align-items: center; padding-bottom: .75rem; border-bottom: 1px solid #f1f5f9; }
        .modal-header h3 { font-size: 1.1rem; color: #0f172a; }
        .modal-close { background: none; border: none; font-size: 1.5rem; cursor: pointer; color: #94a3b8; }
        .modal-close:hover { color: #1e293b; }
        .modal-body { padding-top: 1rem; }

        /* ── RESPONSIVE ── */
        @media(max-width:1024px) { .stats-grid,.energy-section { grid-template-columns: repeat(2,1fr); } }
        @media(max-width:768px) {
            .sidebar { width: 60px; padding: 1rem .5rem; }
            .sidebar-brand .brand-text, .sidebar-nav .nav-item span,
            .sidebar-footer .system-status span, .sidebar-version { display: none; }
            .sidebar-nav .nav-item { justify-content: center; padding: .7rem; }
            .main-content { margin-left: 60px; padding: 1rem; }
            .stats-grid,.energy-section { grid-template-columns: 1fr; }
            .top-header { flex-direction: column; }
        }
        @media(max-width:480px) { .stat-card { flex-direction: column; text-align: center; } .stat-value { font-size: 1.5rem; } }
    </style>
</head>
<body>
<div class="app-container">

    <!-- SIDEBAR -->
    <aside class="sidebar">
        <div class="sidebar-brand">
            <div class="brand-icon"><i class="fas fa-leaf"></i></div>
            <div class="brand-text"><h2>HIDROPONIK</h2><span>Monitoring System</span></div>
        </div>
        <nav class="sidebar-nav">
            <a href="#" class="nav-item active" onclick="navigateTo('dashboard',this)">
                <i class="fas fa-chart-pie"></i><span>Dashboard</span>
            </a>
            <a href="#" class="nav-item" onclick="navigateTo('history',this)">
                <i class="fas fa-history"></i><span>Riwayat</span>
            </a>
            <a href="#" class="nav-item" onclick="navigateTo('kontrol',this)">
                <i class="fas fa-sliders-h"></i><span>Kontrol</span>
            </a>
            <a href="#" class="nav-item" onclick="navigateTo('analisis',this)">
                <i class="fas fa-chart-line"></i><span>Analisis</span>
            </a>
            <a href="#" class="nav-item" onclick="navigateTo('pengaturan',this)">
                <i class="fas fa-cog"></i><span>Pengaturan</span>
            </a>
        </nav>
        <div class="sidebar-footer">
            <div class="system-status"><div class="status-dot online"></div><span>Sistem Aktif</span></div>
            <div class="sidebar-version">v2.0.0</div>
        </div>
    </aside>

    <!-- MAIN CONTENT -->
    <main class="main-content" id="main-content">

        <!-- HEADER -->
        <header class="top-header">
            <div class="header-left">
                <h1>🌿 Dashboard</h1>
                <p class="header-subtitle">Monitoring sistem hidroponik vertikal</p>
            </div>
            <div class="header-right">
                <div class="header-time">
                    <i class="far fa-calendar-alt"></i>
                    <span id="clock-display"><?= $current_time ?></span>
                </div>
                <div class="header-status">
                    <span class="status-badge success"><i class="fas fa-circle"></i> ESP32 <?= $esp_status ?></span>
                    <span class="status-badge success"><i class="fas fa-circle"></i> Database <?= $db_status ?></span>
                    <span class="status-badge <?= $pump_status ? 'success' : 'danger' ?>">
                        <i class="fas fa-circle"></i> Pompa <?= $pump_status ? 'ON' : 'OFF' ?>
                    </span>
                </div>
            </div>
        </header>

        <!-- SENSOR CARDS -->
        <section class="stats-grid">
            <div class="stat-card" onclick="showDetail('Suhu Udara','<?= $temperature ?>°C')">
                <div class="stat-icon temperature"><i class="fas fa-thermometer-half"></i></div>
                <div class="stat-info">
                    <span class="stat-label">Suhu Udara</span>
                    <span class="stat-value" id="temp-value"><?= $temperature ?>°C</span>
                    <span class="stat-status" id="temp-status" style="color:<?= $temperature>30?'#ef4444':($temperature>25?'#f59e0b':'#22c55e') ?>">
                        <?= $temperature>30?'Panas':($temperature>25?'Hangat':'Normal') ?>
                    </span>
                </div>
            </div>
            <div class="stat-card" onclick="showDetail('Kelembaban','<?= $humidity ?>%')">
                <div class="stat-icon humidity"><i class="fas fa-tint"></i></div>
                <div class="stat-info">
                    <span class="stat-label">Kelembaban</span>
                    <span class="stat-value" id="humid-value"><?= $humidity ?>%</span>
                    <span class="stat-status" id="humid-status" style="color:<?= $humidity>75?'#3b82f6':($humidity>55?'#22c55e':'#f59e0b') ?>">
                        <?= $humidity>75?'Lembab':($humidity>55?'Normal':'Kering') ?>
                    </span>
                </div>
            </div>
            <div class="stat-card" onclick="showDetail('TDS','<?= $tds_ppm ?> ppm')">
                <div class="stat-icon tds"><i class="fas fa-flask"></i></div>
                <div class="stat-info">
                    <span class="stat-label">TDS</span>
                    <span class="stat-value" id="tds-value"><?= $tds_ppm ?> ppm</span>
                    <span class="stat-status" id="tds-status" style="color:<?= $tds_ppm>900?'#ef4444':($tds_ppm>500?'#22c55e':'#f59e0b') ?>">
                        <?= $tds_ppm>900?'Tinggi':($tds_ppm>500?'Normal':'Rendah') ?>
                    </span>
                </div>
            </div>
        </section>

        <!-- SOLAR, BATTERY, NUTRISI -->
        <section class="energy-section">
            <div class="energy-card solar" onclick="showDetail('Solar Panel','<?= $solar_status ?>')">
                <div class="energy-header"><i class="fas fa-sun"></i><h3>Solar Panel</h3></div>
                <div class="energy-status <?= $solar_status=='MENGISI'?'charging':'idle' ?>"><?= $solar_status ?></div>
                <div class="energy-details">
                    <div class="energy-item">
                        <span class="energy-label">Arus</span>
                        <span class="energy-value" id="solar-current"><?= $solar_current ?> A</span>
                    </div>
                    <div class="energy-item">
                        <span class="energy-label">Tegangan</span>
                        <span class="energy-value" id="solar-voltage"><?= $solar_voltage ?> V</span>
                    </div>
                </div>
            </div>

            <div class="energy-card battery" onclick="showDetail('Baterai','<?= $battery_level ?>%')">
                <div class="energy-header"><i class="fas fa-bolt"></i><h3>Baterai</h3></div>
                <div class="battery-level" id="battery-level"><?= $battery_level ?>%</div>
                <div class="battery-bar">
                    <div class="battery-fill" id="battery-fill" style="width:<?= $battery_level ?>%;background:<?= $battery_level>70?'#22c55e':($battery_level>40?'#f59e0b':'#ef4444') ?>"></div>
                </div>
                <div class="battery-voltage" id="battery-voltage"><?= $battery_voltage ?> V</div>
            </div>

            <div class="energy-card nutrient" onclick="showDetail('Nutrisi','TDS: <?= $nutrient['tds_ppm'] ?> ppm')">
                <div class="energy-header"><i class="fas fa-seedling"></i><h3>Nutrisi</h3></div>
                <div class="nutrient-item">
                    <span class="nutrient-label">TDS</span>
                    <span class="nutrient-value" id="nutrient-tds"><?= $nutrient['tds_ppm'] ?> ppm</span>
                </div>
                <div class="nutrient-item">
                    <span class="nutrient-label">Water Level</span>
                    <span class="nutrient-value" id="nutrient-water"><?= $water_level ?>%</span>
                </div>
                <div class="nutrient-item">
                    <span class="nutrient-label">Serapan</span>
                    <span class="nutrient-value" id="nutrient-absorption"><?= $nutrient['absorption_rate'] ?? 75 ?>%</span>
                </div>
            </div>
        </section>

        <!-- PUMP CONTROL -->
        <section class="control-section" id="kontrol-section">
            <div class="control-header">
                <h3><i class="fas fa-water"></i> Kontrol Pompa</h3>
                <div class="pump-indicator">
                    <span class="pump-label">Status</span>
                    <span class="pump-status <?= $pump_status?'active':'inactive' ?>" id="pump-status-text">
                        <?= $pump_status?'AKTIF':'NONAKTIF' ?>
                    </span>
                    <span class="pump-timer"><i class="far fa-clock"></i> <span id="timer-display">00:00</span></span>
                </div>
            </div>
            <div class="control-buttons">
                <button class="btn btn-timer"    onclick="pumpControl('on',5)"><i class="fas fa-clock"></i> 5 Detik</button>
                <button class="btn btn-timer"    onclick="pumpControl('on',10)"><i class="fas fa-clock"></i> 10 Detik</button>
                <button class="btn btn-timer"    onclick="pumpControl('on',30)"><i class="fas fa-clock"></i> 30 Detik</button>
                <button class="btn btn-timer"    onclick="pumpControl('on',60)"><i class="fas fa-clock"></i> 60 Detik</button>
                <button class="btn btn-primary"  onclick="pumpControl('on')"><i class="fas fa-play"></i> Hidupkan Pompa</button>
                <button class="btn btn-danger"   onclick="pumpControl('off')"><i class="fas fa-stop"></i> Matikan Pompa</button>
            </div>
            <div class="control-feedback" id="control-feedback">
                <i class="fas fa-info-circle"></i>
                <span id="feedback-text">Klik tombol untuk mengontrol pompa</span>
            </div>
        </section>

        <!-- HISTORY TABLE -->
        <section class="history-section" id="riwayat-section">
            <div class="history-header">
                <h3><i class="fas fa-table"></i> Riwayat Data Sensor</h3>
                <div class="history-controls">
                    <select id="date-filter" onchange="loadHistory(1)" class="date-filter">
                        <option value="">Semua Tanggal</option>
                        <?php
                        $dateResult = $conn->query("SELECT DISTINCT DATE(created_at) as tgl FROM sensor_data ORDER BY tgl DESC");
                        if ($dateResult && $dateResult->num_rows > 0) {
                            while ($row = $dateResult->fetch_assoc()) {
                                $d = new DateTime($row['tgl']);
                                echo "<option value='{$row['tgl']}'>" . $d->format('d F Y') . "</option>";
                            }
                        }
                        ?>
                    </select>
                    <button class="btn-refresh" onclick="loadHistory(1)">
                        <i class="fas fa-sync-alt"></i> Refresh
                    </button>
                </div>
            </div>
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>Waktu</th>
                            <th>Suhu (°C)</th>
                            <th>Kelembaban (%)</th>
                            <th>TDS (ppm)</th>
                            <th>Baterai (%)</th>
                            <th>Pompa</th>
                        </tr>
                    </thead>
                    <tbody id="history-body">
                        <tr><td colspan="6" class="loading-text"><i class="fas fa-spinner fa-spin"></i> Memuat data...</td></tr>
                    </tbody>
                </table>
            </div>
            <div class="pagination" id="pagination"></div>
        </section>
    </main>
</div>

<!-- NOTIFICATION -->
<div id="notification" class="notification">
    <div class="notification-content">
        <i class="fas fa-check-circle" id="notif-icon"></i>
        <span id="notif-text">Notifikasi</span>
    </div>
</div>

<!-- MODAL DETAIL -->
<div id="detail-modal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="modal-title">Detail</h3>
            <button class="modal-close" onclick="closeModal()">&times;</button>
        </div>
        <div class="modal-body"><p id="modal-value">Nilai: -</p></div>
    </div>
</div>

<script>
// ============================================
// VARIABLES
// ============================================
let currentPage = 1;
let totalPages  = 1;
const perPage   = 10;
let pumpTimer   = null;
let timerSeconds= 0;

// ============================================
// LOAD HISTORY TABLE
// ============================================
function loadHistory(page) {
    page = page || currentPage;
    currentPage = page;

    const dateFilter = document.getElementById('date-filter').value;
    const tbody      = document.getElementById('history-body');
    const pagination = document.getElementById('pagination');

    tbody.innerHTML = '<tr><td colspan="6" class="loading-text"><i class="fas fa-spinner fa-spin"></i> Memuat data...</td></tr>';
    pagination.innerHTML = '';

    const params = new URLSearchParams({ page: page, per_page: perPage });
    if (dateFilter) params.append('date', dateFilter);

    fetch('../api/get_history.php?' + params.toString())
        .then(r => r.json())
        .then(data => {
            if (!data.data || data.data.length === 0) {
                tbody.innerHTML = '<tr><td colspan="6" class="loading-text">Tidak ada data</td></tr>';
                return;
            }

            totalPages = Math.ceil(data.total / perPage);

            tbody.innerHTML = data.data.map(row => `
                <tr>
                    <td>${row.created_at}</td>
                    <td>${row.suhu}</td>
                    <td>${row.kelembapan}</td>
                    <td>${row.tds}</td>
                    <td>${row.baterai}</td>
                    <td>
                        <span class="pump-status ${row.pump_status == 1 ? 'active' : 'inactive'}">
                            ${row.pump_status == 1 ? 'AKTIF' : 'NONAKTIF'}
                        </span>
                    </td>
                </tr>
            `).join('');

            // Pagination
            let pHtml = '';
            if (totalPages > 1) {
                pHtml += `<button class="page-btn" onclick="loadHistory(${page-1})" ${page<=1?'disabled':''}>&#8592; Prev</button>`;
                const start = Math.max(1, page - 2);
                const end   = Math.min(totalPages, page + 2);
                for (let i = start; i <= end; i++) {
                    pHtml += `<button class="page-btn ${i===page?'active':''}" onclick="loadHistory(${i})">${i}</button>`;
                }
                pHtml += `<button class="page-btn" onclick="loadHistory(${page+1})" ${page>=totalPages?'disabled':''}>Next &#8594;</button>`;
            }
            pagination.innerHTML = pHtml;
        })
        .catch(() => {
            tbody.innerHTML = '<tr><td colspan="6" class="loading-text"><i class="fas fa-exclamation-circle"></i> Gagal memuat data</td></tr>';
        });
}

// ============================================
// UPDATE LATEST DATA
// ============================================
function updateLatestData() {
    fetch('../api/get_latest.php')
        .then(r => r.json())
        .then(data => {
            // Suhu
            if (data.suhu !== undefined) {
                document.getElementById('temp-value').innerText = data.suhu + '°C';
                const s = document.getElementById('temp-status');
                if (data.suhu > 30)      { s.innerText = 'Panas';  s.style.color = '#ef4444'; }
                else if (data.suhu > 25) { s.innerText = 'Hangat'; s.style.color = '#f59e0b'; }
                else                      { s.innerText = 'Normal'; s.style.color = '#22c55e'; }
            }
            // Kelembapan
            if (data.kelembapan !== undefined) {
                document.getElementById('humid-value').innerText = data.kelembapan + '%';
                const s = document.getElementById('humid-status');
                if (data.kelembapan > 75)      { s.innerText = 'Lembab'; s.style.color = '#3b82f6'; }
                else if (data.kelembapan > 55) { s.innerText = 'Normal'; s.style.color = '#22c55e'; }
                else                            { s.innerText = 'Kering'; s.style.color = '#f59e0b'; }
            }
            // TDS
            if (data.tds !== undefined) {
                document.getElementById('tds-value').innerText    = data.tds + ' ppm';
                document.getElementById('nutrient-tds').innerText = data.tds + ' ppm';
                const s = document.getElementById('tds-status');
                if (data.tds > 900)      { s.innerText = 'Tinggi'; s.style.color = '#ef4444'; }
                else if (data.tds > 500) { s.innerText = 'Normal'; s.style.color = '#22c55e'; }
                else                      { s.innerText = 'Rendah'; s.style.color = '#f59e0b'; }
            }
            // Water level
            if (data.water_level !== undefined)
                document.getElementById('nutrient-water').innerText = data.water_level + '%';
            // Baterai
            if (data.baterai !== undefined) {
                document.getElementById('battery-level').innerText   = data.baterai + '%';
                document.getElementById('battery-fill').style.width  = data.baterai + '%';
                document.getElementById('battery-fill').style.background =
                    data.baterai > 70 ? '#22c55e' : (data.baterai > 40 ? '#f59e0b' : '#ef4444');
            }
            // Battery voltage
            if (data.battery_voltage !== undefined)
                document.getElementById('battery-voltage').innerText = data.battery_voltage + ' V';
            // Solar
            if (data.arus_surya !== undefined)
                document.getElementById('solar-current').innerText = data.arus_surya + ' A';
            if (data.tegangan_surya !== undefined)
                document.getElementById('solar-voltage').innerText = data.tegangan_surya + ' V';
            // Pump
            if (data.pump_status !== undefined) {
                const el = document.getElementById('pump-status-text');
                if (data.pump_status == 1) { el.innerText = 'AKTIF';    el.className = 'pump-status active'; }
                else                        { el.innerText = 'NONAKTIF'; el.className = 'pump-status inactive'; }
            }
        })
        .catch(e => console.error('updateLatestData:', e));
}

// ============================================
// NAVIGASI
// ============================================
function navigateTo(page, el) {
    document.querySelectorAll('.nav-item').forEach(i => i.classList.remove('active'));
    if (el) el.classList.add('active');

    if (page === 'history') {
        document.getElementById('riwayat-section').scrollIntoView({ behavior: 'smooth' });
        loadHistory(1);
    } else if (page === 'kontrol') {
        document.getElementById('kontrol-section').scrollIntoView({ behavior: 'smooth' });
    } else if (page === 'dashboard') {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
        showNotification('info', 'Fitur ' + page + ' sedang dikembangkan');
    }
    return false;
}

// ============================================
// PUMP CONTROL
// ============================================
function pumpControl(action, duration) {
    duration = duration || null;
    const feedback   = document.getElementById('feedback-text');
    const statusText = document.getElementById('pump-status-text');

    if (action === 'on') {
        const msg = duration ? 'Pompa dinyalakan selama ' + duration + ' detik' : 'Pompa dinyalakan';
        feedback.innerHTML = '<i class="fas fa-play-circle" style="color:#22c55e;margin-right:.4rem"></i>' + msg;
        statusText.innerText = 'AKTIF'; statusText.className = 'pump-status active';
        if (duration) startTimer(duration);
    } else {
        feedback.innerHTML = '<i class="fas fa-stop-circle" style="color:#ef4444;margin-right:.4rem"></i>Pompa dimatikan';
        statusText.innerText = 'NONAKTIF'; statusText.className = 'pump-status inactive';
        stopTimer();
    }

    fetch('../api/pump_control.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: action, duration: duration })
    })
    .then(r => r.json())
    .then(d => {
        showNotification('success', d.message || (action === 'on' ? 'Pompa dinyalakan' : 'Pompa dimatikan'));
        loadHistory(currentPage);
        updateLatestData();
    })
    .catch(() => showNotification('error', 'Gagal mengontrol pompa'));
}

// ============================================
// TIMER
// ============================================
function startTimer(duration) {
    stopTimer();
    timerSeconds = duration;
    updateTimerDisplay();
    pumpTimer = setInterval(() => {
        timerSeconds--;
        updateTimerDisplay();
        if (timerSeconds <= 0) {
            stopTimer();
            pumpControl('off');
            showNotification('info', '⏰ Pompa mati otomatis!');
        }
    }, 1000);
}
function stopTimer() {
    if (pumpTimer) { clearInterval(pumpTimer); pumpTimer = null; }
    timerSeconds = 0;
    document.getElementById('timer-display').innerText = '00:00';
}
function updateTimerDisplay() {
    const m = Math.floor(timerSeconds / 60);
    const s = timerSeconds % 60;
    document.getElementById('timer-display').innerText =
        String(m).padStart(2,'0') + ':' + String(s).padStart(2,'0');
}

// ============================================
// NOTIFICATION
// ============================================
function showNotification(type, message) {
    const notif = document.getElementById('notification');
    const icon  = document.getElementById('notif-icon');
    const text  = document.getElementById('notif-text');
    notif.className = 'notification ' + type;
    icon.className  = type === 'success' ? 'fas fa-check-circle' : (type === 'error' ? 'fas fa-exclamation-circle' : 'fas fa-info-circle');
    text.innerText  = message;
    notif.style.display = 'block';
    notif.style.opacity = '1';
    clearTimeout(notif._t);
    notif._t = setTimeout(() => {
        notif.style.opacity = '0';
        setTimeout(() => { notif.style.display = 'none'; }, 300);
    }, 3000);
}

// ============================================
// MODAL
// ============================================
function showDetail(title, value) {
    document.getElementById('modal-title').innerText  = title;
    document.getElementById('modal-value').innerHTML  = '<strong>Nilai:</strong> ' + value;
    document.getElementById('detail-modal').style.display = 'flex';
}
function closeModal() { document.getElementById('detail-modal').style.display = 'none'; }
window.onclick = e => { if (e.target === document.getElementById('detail-modal')) closeModal(); };

// ============================================
// CLOCK
// ============================================
function updateClock() {
    const el = document.getElementById('clock-display');
    if (el) el.innerText = new Date().toLocaleDateString('id-ID', {
        weekday:'long', year:'numeric', month:'long', day:'numeric',
        hour:'2-digit', minute:'2-digit', second:'2-digit'
    });
}

// ============================================
// INIT
// ============================================
document.addEventListener('DOMContentLoaded', () => {
    loadHistory(1);
    updateClock();
    updateLatestData();
    setInterval(updateClock, 1000);
    setInterval(loadHistory.bind(null, currentPage), 30000);
    setInterval(updateLatestData, 5000);
});
</script>
</body>
</html>