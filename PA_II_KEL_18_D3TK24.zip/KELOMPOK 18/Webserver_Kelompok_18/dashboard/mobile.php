<?php
// ==============================================
// HIDROPONIK MOBILE 
// ==============================================

require_once '../config/database.php';
require_once '../includes/functions.php';

$sensor = getLatestSensorData($conn);
$solar = getSolarStatus();
$nutrient = getNutrientStatus();
$temperature = $sensor ? $sensor['temperature'] : 0;
$humidity = $sensor ? $sensor['humidity'] : 0;
$tds_ppm = $sensor ? $sensor['tds_ppm'] : 0;
$ph_level = $sensor ? $sensor['ph_level'] : 0;
$pump_status = $sensor ? $sensor['pump_status'] : 0;
$battery_level = $solar['battery_level'];
$solar_status = $solar['solar_status'];
$solar_current = $solar['solar_current'];
$solar_voltage = $solar['solar_voltage'];
$battery_voltage = $solar['battery_voltage'];

date_default_timezone_set('Asia/Jakarta');
$waktu = date('H:i:s');
$tanggal = date('d/m/Y');
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="theme-color" content="#0a0e1a">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <title>HIDROPONIK</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            -webkit-tap-highlight-color: transparent;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background: #0b111e;
            color: #e8edf5;
            padding: 0;
            min-height: 100vh;
            padding-bottom: 30px;
        }

        /* ==================== HEADER ==================== */
        .header {
            background: linear-gradient(135deg, #0d1a2b, #162033);
            padding: 20px 20px 16px;
            border-bottom: 1px solid rgba(255,255,255,0.04);
        }

        .header .atas {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header .judul {
            font-size: 22px;
            font-weight: 800;
            letter-spacing: 1px;
        }
        .header .judul span {
            color: #4ade80;
        }

        .header .sub-judul {
            font-size: 11px;
            color: #6a7f9e;
            letter-spacing: 2px;
            text-transform: uppercase;
            margin-top: 2px;
        }

        .header .jam {
            font-size: 15px;
            font-weight: 600;
            color: #94a3b8;
            background: rgba(255,255,255,0.04);
            padding: 4px 14px;
            border-radius: 20px;
        }

        /* ==================== NAV SIDEBAR ==================== */
        .nav-horizontal {
            display: flex;
            gap: 4px;
            padding: 12px 16px 8px;
            border-bottom: 1px solid rgba(255,255,255,0.03);
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }

        .nav-horizontal::-webkit-scrollbar {
            display: none;
        }

        .nav-item {
            padding: 6px 16px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            color: #6a7f9e;
            white-space: nowrap;
            text-decoration: none;
            transition: 0.2s;
            background: transparent;
        }

        .nav-item.aktif {
            color: #4ade80;
            background: rgba(74, 222, 128, 0.08);
        }

        .nav-item:active {
            opacity: 0.6;
        }

        /* ==================== SOLAR PANEL ==================== */
        .solar-card {
            background: #132030;
            border-radius: 16px;
            margin: 16px 16px 12px;
            padding: 18px 20px;
            border: 1px solid rgba(255,255,255,0.04);
        }

        .solar-card .judul-solar {
            font-size: 13px;
            color: #7a8fa8;
            font-weight: 500;
            margin-bottom: 8px;
        }

        .solar-card .status-solar {
            font-size: 18px;
            font-weight: 700;
        }
        .status-solar.hijau { color: #4ade80; }
        .status-solar.kuning { color: #fbbf24; }
        .status-solar.abu { color: #6a7f9e; }

        .solar-card .detail-solar {
            display: flex;
            gap: 24px;
            margin-top: 6px;
        }

        .solar-card .detail-solar .item {
            display: flex;
            flex-direction: column;
        }
        .solar-card .detail-solar .label {
            font-size: 10px;
            color: #4a5f7e;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .solar-card .detail-solar .nilai {
            font-size: 15px;
            font-weight: 600;
        }

        /* ==================== BATERAI ==================== */
        .baterai-card {
            background: #132030;
            border-radius: 16px;
            margin: 0 16px 12px;
            padding: 16px 20px 18px;
            border: 1px solid rgba(255,255,255,0.04);
        }

        .baterai-card .atas-baterai {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .baterai-card .label-baterai {
            font-size: 13px;
            color: #7a8fa8;
            font-weight: 500;
        }

        .baterai-card .level-baterai {
            font-size: 28px;
            font-weight: 800;
        }

        .baterai-card .batang {
            width: 100%;
            height: 6px;
            background: #0b111e;
            border-radius: 10px;
            overflow: hidden;
            margin: 6px 0 4px;
        }
        .baterai-card .batang .isi {
            height: 100%;
            border-radius: 10px;
            transition: width 0.6s;
        }

        .baterai-card .volt-baterai {
            font-size: 13px;
            color: #6a7f9e;
            text-align: right;
        }

        /* ==================== GRID SENSOR ==================== */
        .grid-sensor {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
            padding: 0 16px 12px;
        }

        .kartu-sensor {
            background: #132030;
            border-radius: 14px;
            padding: 14px 12px 12px;
            border: 1px solid rgba(255,255,255,0.04);
            text-align: center;
        }

        .kartu-sensor:active {
            transform: scale(0.96);
            background: #1a2a3e;
        }

        .kartu-sensor .ikon {
            font-size: 18px;
        }
        .kartu-sensor .label {
            font-size: 10px;
            color: #6a7f9e;
            text-transform: uppercase;
            letter-spacing: 0.3px;
            margin-top: 2px;
        }
        .kartu-sensor .nilai {
            font-size: 20px;
            font-weight: 700;
            color: #dce6f2;
            margin: 2px 0;
        }
        .kartu-sensor .status {
            font-size: 10px;
        }
        .kartu-sensor .status.normal { color: #4ade80; }
        .kartu-sensor .status.tinggi { color: #fbbf24; }
        .kartu-sensor .status.rendah { color: #6a7f9e; }
        .kartu-sensor .status.ideal { color: #4ade80; }

        /* ==================== NUTRISI ==================== */
        .nutrisi-card {
            background: #132030;
            border-radius: 16px;
            margin: 0 16px 12px;
            padding: 14px 18px;
            border: 1px solid rgba(255,255,255,0.04);
        }

        .nutrisi-card .judul-nutrisi {
            font-size: 13px;
            color: #7a8fa8;
            font-weight: 500;
            margin-bottom: 6px;
        }

        .nutrisi-card .baris {
            display: flex;
            justify-content: space-between;
            padding: 4px 0;
            border-bottom: 1px solid rgba(255,255,255,0.03);
        }
        .nutrisi-card .baris:last-child {
            border-bottom: none;
        }
        .nutrisi-card .label-kiri {
            color: #6a7f9e;
            font-size: 13px;
        }
        .nutrisi-card .nilai-kanan {
            font-weight: 600;
            font-size: 14px;
        }

        /* ==================== KONTROL POMPA ==================== */
        .kontrol-card {
            background: #132030;
            border-radius: 16px;
            margin: 0 16px 12px;
            padding: 16px 18px;
            border: 1px solid rgba(255,255,255,0.04);
        }

        .kontrol-card .header-kontrol {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 12px;
        }

        .kontrol-card .header-kontrol .label {
            font-weight: 600;
            font-size: 14px;
        }

        .kontrol-card .header-kontrol .status-pompa {
            font-size: 12px;
            font-weight: 600;
            padding: 2px 14px;
            border-radius: 20px;
        }
        .status-pompa.aktif {
            color: #4ade80;
            background: rgba(74, 222, 128, 0.1);
        }
        .status-pompa.nonaktif {
            color: #f87171;
            background: rgba(239, 68, 68, 0.1);
        }

        .tombol-group {
            display: flex;
            gap: 6px;
            flex-wrap: wrap;
        }

        .tombol {
            flex: 1;
            min-width: 52px;
            padding: 10px 4px;
            border: none;
            border-radius: 10px;
            font-size: 11px;
            font-weight: 600;
            color: #fff;
            cursor: pointer;
            transition: 0.15s;
            background: #1f3042;
            text-align: center;
            font-family: inherit;
        }

        .tombol:active {
            transform: scale(0.94);
            opacity: 0.7;
        }

        .tombol.hijau { background: #1e8a4a; }
        .tombol.merah { background: #b91c1c; }
        .tombol.biru { background: #1a4a8a; }

        .feedback {
            font-size: 12px;
            color: #6a7f9e;
            margin-top: 10px;
            text-align: center;
        }
        .feedback.berhasil { color: #4ade80; }
        .feedback.gagal { color: #f87171; }

        /* ==================== RIWAYAT ==================== */
        .riwayat-card {
            background: #132030;
            border-radius: 16px;
            margin: 0 16px 12px;
            padding: 14px 16px;
            border: 1px solid rgba(255,255,255,0.04);
        }

        .riwayat-card .judul-riwayat {
            font-size: 13px;
            font-weight: 600;
            color: #8aa3c9;
            margin-bottom: 10px;
        }

        .riwayat-card .item {
            display: flex;
            justify-content: space-between;
            padding: 6px 0;
            border-bottom: 1px solid rgba(255,255,255,0.03);
            font-size: 12px;
            color: #9ab0cc;
        }
        .riwayat-card .item:last-child { border-bottom: none; }
        .riwayat-card .item .waktu { color: #6a7f9e; }
        .riwayat-card .item .data { font-weight: 500; }
        .riwayat-card .item .data.on { color: #4ade80; }
        .riwayat-card .item .data.off { color: #f87171; }

        .refresh-btn {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: transparent;
            border: 1px solid rgba(255,255,255,0.06);
            color: #6a7f9e;
            padding: 6px 18px;
            border-radius: 20px;
            font-size: 11px;
            cursor: pointer;
            margin-top: 6px;
            font-family: inherit;
        }
        .refresh-btn:active { background: rgba(255,255,255,0.04); }

        /* ==================== FOOTER ==================== */
        .footer {
            text-align: center;
            font-size: 10px;
            color: #3a4f6e;
            padding: 16px 16px 8px;
            border-top: 1px solid rgba(255,255,255,0.03);
            margin: 8px 16px 0;
        }

        /* ==================== NOTIFIKASI ==================== */
        .notif {
            position: fixed;
            bottom: 30px;
            left: 50%;
            transform: translateX(-50%) translateY(80px);
            background: #1a2a3e;
            padding: 12px 24px;
            border-radius: 14px;
            font-size: 13px;
            font-weight: 500;
            color: #e8edf5;
            box-shadow: 0 8px 30px rgba(0,0,0,0.6);
            opacity: 0;
            transition: 0.4s ease;
            z-index: 99;
            pointer-events: none;
            border: 1px solid rgba(255,255,255,0.06);
            max-width: 90%;
            text-align: center;
            font-family: inherit;
        }
        .notif.muncul {
            opacity: 1;
            transform: translateX(-50%) translateY(0);
        }
        .notif.berhasil { border-color: rgba(74, 222, 128, 0.2); }
        .notif.gagal { border-color: rgba(239, 68, 68, 0.2); }

        /* ==================== RESPONSIF ==================== */
        @media (max-width: 400px) {
            .grid-sensor { gap: 6px; }
            .kartu-sensor { padding: 10px 8px; }
            .kartu-sensor .nilai { font-size: 16px; }
            .tombol { font-size: 10px; padding: 8px 4px; min-width: 44px; }
            .header .judul { font-size: 18px; }
            .solar-card .detail-solar { gap: 14px; }
        }

        @media (max-width: 360px) {
            .grid-sensor { grid-template-columns: 1fr 1fr; }
            .tombol-group { gap: 4px; }
            .tombol { min-width: 38px; font-size: 9px; padding: 6px 2px; }
        }
    </style>
</head>
<body>

    <!-- ==================== HEADER ==================== -->
    <div class="header">
        <div class="atas">
            <div>
                <div class="judul">🌱 <span>HIDROPONIK</span></div>
                <div class="sub-judul">Monitoring System</div>
            </div>
            <div class="jam"><?= $waktu ?></div>
        </div>
    </div>

    <!-- ==================== NAV HORIZONTAL ==================== -->
    <div class="nav-horizontal">
        <a href="#" class="nav-item aktif">Dashboard</a>
        <a href="#" class="nav-item" onclick="notif('Riwayat')">Riwayat</a>
        <a href="#" class="nav-item" onclick="notif('Analisis')">Analisis</a>
        <a href="#" class="nav-item" onclick="notif('Kontrol')">Kontrol</a>
        <a href="#" class="nav-item" onclick="notif('Pengaturan')">Pengaturan</a>
    </div>

    <!-- ==================== SOLAR PANEL ==================== -->
    <div class="solar-card">
        <div class="judul-solar">☀️ Solar Panel</div>
        <div class="status-solar <?= $solar_status == 'MENGISI' ? 'hijau' : ($solar_status == 'TIDAK MENGISI' ? 'abu' : 'kuning') ?>">
            <?= $solar_status ?>
        </div>
        <div class="detail-solar">
            <div class="item">
                <span class="label">Arus</span>
                <span class="nilai"><?= $solar_current ?> A</span>
            </div>
            <div class="item">
                <span class="label">Tegangan</span>
                <span class="nilai"><?= $solar_voltage ?> V</span>
            </div>
        </div>
    </div>

    <!-- ==================== BATERAI ==================== -->
    <div class="baterai-card">
        <div class="atas-baterai">
            <span class="label-baterai">🔋 Baterai</span>
            <span class="level-baterai"><?= $battery_level ?>%</span>
        </div>
        <div class="batang">
            <div class="isi" style="width:<?= $battery_level ?>%; background:<?= $battery_level > 70 ? '#4ade80' : ($battery_level > 40 ? '#fbbf24' : '#f87171') ?>"></div>
        </div>
        <div class="volt-baterai"><?= $battery_voltage ?> V</div>
    </div>

    <!-- ==================== GRID SENSOR ==================== -->
    <div class="grid-sensor">
        <div class="kartu-sensor" onclick="notif('Suhu: <?= $temperature ?>°C')">
            <div class="ikon">🌡️</div>
            <div class="label">Suhu</div>
            <div class="nilai"><?= $temperature ?>°</div>
            <div class="status <?= $temperature > 30 ? 'tinggi' : 'normal' ?>">
                <?= $temperature > 30 ? 'Panas' : ($temperature > 25 ? 'Hangat' : 'Normal') ?>
            </div>
        </div>

        <div class="kartu-sensor" onclick="notif('Kelembaban: <?= $humidity ?>%')">
            <div class="ikon">💧</div>
            <div class="label">Kelembaban</div>
            <div class="nilai"><?= $humidity ?>%</div>
            <div class="status <?= $humidity > 80 ? 'tinggi' : 'normal' ?>">
                <?= $humidity > 80 ? 'Lembab' : 'Normal' ?>
            </div>
        </div>

        <div class="kartu-sensor" onclick="notif('TDS: <?= $tds_ppm ?> ppm')">
            <div class="ikon">🧪</div>
            <div class="label">TDS</div>
            <div class="nilai"><?= $tds_ppm ?></div>
            <div class="status <?= $tds_ppm > 900 ? 'tinggi' : 'normal' ?>">
                <?= $tds_ppm > 900 ? 'Tinggi' : 'Normal' ?>
            </div>
        </div>

        <div class="kartu-sensor" onclick="notif('pH: <?= $ph_level ?>')">
            <div class="ikon">⚗️</div>
            <div class="label">pH Air</div>
            <div class="nilai"><?= $ph_level ?></div>
            <div class="status <?= $ph_level > 6.0 && $ph_level <= 7.5 ? 'ideal' : 'rendah' ?>">
                <?= $ph_level > 7.5 ? 'Basa' : ($ph_level > 6.0 ? 'Ideal' : 'Asam') ?>
            </div>
        </div>
    </div>

    <!-- ==================== NUTRISI ==================== -->
    <div class="nutrisi-card">
        <div class="judul-nutrisi">🌿 Nutrisi</div>
        <div class="baris">
            <span class="label-kiri">TDS</span>
            <span class="nilai-kanan"><?= $nutrient['tds_ppm'] ?> ppm</span>
        </div>
        <div class="baris">
            <span class="label-kiri">pH</span>
            <span class="nilai-kanan"><?= $nutrient['ph_level'] ?></span>
        </div>
        <div class="baris" style="border-bottom: none;">
            <span class="label-kiri">Serapan</span>
            <span class="nilai-kanan" style="color:#4ade80;"><?= $nutrient['absorption_rate'] ?>%</span>
        </div>
    </div>

    <!-- ==================== KONTROL POMPA ==================== -->
    <div class="kontrol-card">
        <div class="header-kontrol">
            <span class="label">🔄 Kontrol Pompa</span>
            <span class="status-pompa <?= $pump_status ? 'aktif' : 'nonaktif' ?>">
                <?= $pump_status ? '● AKTIF' : '● NONAKTIF' ?>
            </span>
        </div>

        <div class="tombol-group">
            <button class="tombol biru" onclick="pompa('on',5)">5 Detik</button>
            <button class="tombol biru" onclick="pompa('on',10)">10 Detik</button>
            <button class="tombol biru" onclick="pompa('on',30)">30 Detik</button>
            <button class="tombol biru" onclick="pompa('on',60)">60 Detik</button>
            <button class="tombol hijau" onclick="pompa('on')">Hidupkan</button>
            <button class="tombol merah" onclick="pompa('off')">Matikan</button>
        </div>

        <div id="feedback" class="feedback">Ketuk tombol untuk kontrol pompa</div>
    </div>

    <!-- ==================== RIWAYAT ==================== -->
    <div class="riwayat-card">
        <div class="judul-riwayat">📋 Riwayat Data Sensor</div>
        <div id="riwayat-list">
            <div style="text-align:center; color:#4a5f7e; padding:10px 0; font-size:12px;">Memuat...</div>
        </div>
        <div style="text-align:center; margin-top:4px;">
            <button class="refresh-btn" onclick="ambilRiwayat()">
                <i class="fas fa-sync-alt"></i> Refresh
            </button>
        </div>
    </div>

    <!-- ==================== FOOTER ==================== -->
    <div class="footer">
        Institut Teknologi Del · Kelompok 18 · v2.0
    </div>

    <!-- ==================== NOTIFIKASI ==================== -->
    <div id="notif" class="notif">Pesan</div>

    <script>
        // ============================================
        // FUNGSI POMPA
        // ============================================
        function pompa(action, durasi = 0) {
            const fb = document.getElementById('feedback');
            const tombol = document.querySelectorAll('.tombol');
            tombol.forEach(b => b.disabled = true);

            fb.textContent = '⏳ Memproses...';
            fb.className = 'feedback';

            const data = new FormData();
            data.append('action', action);
            if (durasi > 0) data.append('duration', durasi);

            fetch('../api/pump_control.php', {
                method: 'POST',
                body: data
            })
            .then(res => res.json())
            .then(res => {
                if (res.status === 'success') {
                    fb.textContent = '✅ ' + res.message;
                    fb.className = 'feedback berhasil';
                    notif(res.message);
                    setTimeout(() => location.reload(), 800);
                } else {
                    fb.textContent = '❌ Gagal: ' + res.message;
                    fb.className = 'feedback gagal';
                    notif('Gagal: ' + res.message, 'gagal');
                }
            })
            .catch(err => {
                fb.textContent = '❌ Error: ' + err.message;
                fb.className = 'feedback gagal';
                notif('Error: ' + err.message, 'gagal');
            })
            .finally(() => {
                tombol.forEach(b => b.disabled = false);
            });
        }

        // ============================================
        // NOTIFIKASI
        // ============================================
        function notif(pesan, tipe = 'berhasil') {
            const el = document.getElementById('notif');
            el.textContent = pesan;
            el.className = 'notif ' + tipe;
            setTimeout(() => el.classList.add('muncul'), 50);
            clearTimeout(el._timer);
            el._timer = setTimeout(() => el.classList.remove('muncul'), 3000);
        }

        // ============================================
        // AMBIL RIWAYAT
        // ============================================
        function ambilRiwayat() {
            const list = document.getElementById('riwayat-list');
            list.innerHTML = '<div style="text-align:center; color:#4a5f7e; padding:10px 0; font-size:12px;">Memuat...</div>';

            fetch('../api/get_history.php?limit=5')
                .then(res => res.json())
                .then(data => {
                    if (data.status === 'success' && data.data.length > 0) {
                        let html = '';
                        data.data.forEach(row => {
                            const waktu = row.created_at ? row.created_at.slice(11, 16) : '--:--';
                            const statusPompa = row.pump_status ? 'ON' : 'OFF';
                            const kelasPompa = row.pump_status ? 'on' : 'off';
                            html += `
                                <div class="item">
                                    <span class="waktu">${waktu}</span>
                                    <span class="data ${kelasPompa}">${row.temperature}°C · ${row.humidity}% · ${statusPompa}</span>
                                </div>
                            `;
                        });
                        list.innerHTML = html;
                    } else {
                        list.innerHTML = '<div style="text-align:center; color:#4a5f7e; padding:10px 0;font-size:12px;">Belum ada data</div>';
                    }
                })
                .catch(() => {
                    list.innerHTML = '<div style="text-align:center; color:#4a5f7e; padding:10px 0;font-size:12px;">Gagal memuat</div>';
                });
        }

        // ============================================
        // AUTO REFRESH
        // ============================================
        ambilRiwayat();

        // Refresh history tiap 30 detik
        setInterval(ambilRiwayat, 30000);

        // Refresh halaman tiap 2 menit
        setInterval(() => {
            location.reload();
        }, 120000);

        console.log('🌱 Hidroponik Mobile siap!');
    </script>
</body>
</html>