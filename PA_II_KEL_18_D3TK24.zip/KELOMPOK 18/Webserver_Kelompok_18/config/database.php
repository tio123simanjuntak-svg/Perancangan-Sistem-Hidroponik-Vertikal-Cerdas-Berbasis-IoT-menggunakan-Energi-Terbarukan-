<?php
// ==============================================
// DATABASE CONFIGURATION - HIDROPONIK VERTIKAL
// ==============================================

// Konfigurasi Database
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'hidroponik_vertikal');   // ← Sudah benar

// Konfigurasi openSenseMap (opsional)
define('OPENSENSE_BOX_ID', '5c7c4f8b9f8b4c001a8b4c2d'); 

// Buat koneksi
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Set charset
$conn->set_charset("utf8mb4");

// Set timezone Indonesia
date_default_timezone_set('Asia/Jakarta');

// ==============================================
// CEK TABEL (Sesuai dengan database kamu)
// ==============================================

// Cek apakah tabel sensor_data ada
$checkTable = $conn->query("SHOW TABLES LIKE 'sensor_data'");
if ($checkTable->num_rows == 0) {
    echo "<div style='color:red; padding:20px;'>Tabel 'sensor_data' tidak ditemukan di database hidroponik_vertikal!</div>";
} else {
    // debug_log("Tabel sensor_data ditemukan");
}

// Fungsi helper debug (opsional)
function debug_log($message) {
    error_log(date('Y-m-d H:i:s') . " - " . $message);
}

// Koneksi berhasil
// debug_log("Database connected successfully");
?>